IF USER_ID('Aplicativos') IS NOT NULL
	BEGIN
		ALTER AUTHORIZATION ON SCHEMA::[pas] TO [dbo];

		GRANT EXECUTE ON SCHEMA::[pas] TO [Aplicativos];
	END
GO
