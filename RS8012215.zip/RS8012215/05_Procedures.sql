USE [PDPJD005]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliCanal01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsAplicCliCanal01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsAplicCliCanal01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsAplicCliServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsAplicCliServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsEscpoAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsEscpoAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsEscpoAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsEscpoAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsGeracTokenAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsGeracTokenAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsMtodoGeracToken01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsMtodoGeracToken01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsPrfilAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsPrfilAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsPrfilAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsPrfilAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal07_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal07_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal07_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz02_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz02_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz03_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz03_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz04_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz04_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz04_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz05_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz05_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz05_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz06_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz06_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz06_v1]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal08_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal08_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal08_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliCanal01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdAplicCliCanal01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdAplicCliCanal01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdAplicCliServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdAplicCliServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdEscpoAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdEscpoAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdEscpoAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdEscpoAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdGeracTokenAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdGeracTokenAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdMtodoGeracToken01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdMtodoGeracToken01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdPrfilAcssoAplicCli01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdPrfilAcssoAplicCli01_v1]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdPrfilAcssoServdAutrz01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdPrfilAcssoServdAutrz01_v1]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliCanal01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelAplicCliCanal01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelAplicCliCanal01]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliCanal02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelAplicCliCanal02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelAplicCliCanal02]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelAplicCliServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelAplicCliServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelEscpoAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelEscpoAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelEscpoAcssoAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelEscpoAcssoAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelEscpoAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelEscpoAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pDelGeracTokenAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelGeracTokenAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelGeracTokenAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pDelGeracTokenAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelGeracTokenAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelGeracTokenAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pDelMtodoGeracToken01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelMtodoGeracToken01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelMtodoGeracToken01]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelPrfilAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelPrfilAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelPrfilAcssoAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelPrfilAcssoAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pDelPrfilAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pDelPrfilAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliCanal01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsAplicCliCanal01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsAplicCliCanal01]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsAplicCliServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsAplicCliServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsEscpoAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsEscpoAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsEscpoAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsEscpoAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pInsGeracTokenAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsGeracTokenAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsGeracTokenAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pInsMtodoGeracToken01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsMtodoGeracToken01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsMtodoGeracToken01]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsPrfilAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsPrfilAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pInsPrfilAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pInsPrfilAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal01]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal02]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal03]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal04]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal05]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal07]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal07]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal07]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal06]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz02]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz03]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz04]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliServdAutrz05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliServdAutrz05]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli04]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli06]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli03]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoAplicCli05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoAplicCli05]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz04]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz02]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz03]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz05]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelEscpoAcssoServdAutrz06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelEscpoAcssoServdAutrz06]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli03]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli06]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli04]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelGeracTokenAplicCli05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelGeracTokenAplicCli05]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken01]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken02]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken03]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken04]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken05]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelMtodoGeracToken06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelMtodoGeracToken06]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli02]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli03]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli06]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli04]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoAplicCli05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoAplicCli05]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz02]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz02]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz03]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz03]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz04]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz04]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz04]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz05]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz05]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz05]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz06]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelPrfilAcssoServdAutrz06]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelPrfilAcssoServdAutrz06]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal08]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pSelAplicCliCanal08]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pSelAplicCliCanal08]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliCanal01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdAplicCliCanal01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdAplicCliCanal01]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdAplicCliServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdAplicCliServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdEscpoAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdEscpoAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdEscpoAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdEscpoAcssoServdAutrz01]
GO

/****** Object:  StoredProcedure [pas].[pUpdGeracTokenAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdGeracTokenAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdGeracTokenAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pUpdMtodoGeracToken01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdMtodoGeracToken01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdMtodoGeracToken01]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdPrfilAcssoAplicCli01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdPrfilAcssoAplicCli01]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:02:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pas].[pUpdPrfilAcssoServdAutrz01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pas].[pUpdPrfilAcssoServdAutrz01]
GO




/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:13 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdPrfilAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT,
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdPrfilAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cPrfilAcssoServdAutrz,
            @iPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdPrfilAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdPrfilAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT,
    @cSitPrfilAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdPrfilAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cPrfilAcssoServdAutrz,
            @cSitPrfilAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdPrfilAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdMtodoGeracToken01]    Script Date: 16/02/2022 19:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdMtodoGeracToken01]
(
    @dbVersion INTEGER,
    @cMtodoGeracToken TINYINT,
    @iMtodoGeracToken CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdMtodoGeracToken01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMtodoGeracToken,
            @iMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdMtodoGeracToken01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdGeracTokenAplicCli01]    Script Date: 16/02/2022 19:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdGeracTokenAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT,
    @cSitTokenAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdGeracTokenAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cMtodoGeracToken,
            @cSitTokenAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdGeracTokenAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdEscpoAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT,
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdEscpoAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cEscpoAcssoServdAutrz,
            @iEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdEscpoAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:04:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdEscpoAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT,
    @cSitEscpoAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdEscpoAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cEscpoAcssoServdAutrz,
            @cSitEscpoAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdEscpoAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliServdAutrz01]    Script Date: 16/02/2022 19:04:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdAplicCliServdAutrz01]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdAplicCliServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz,
            @iAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdAplicCliServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliCanal01]    Script Date: 16/02/2022 19:04:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdAplicCliCanal01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @wChaveSecrtCript VARCHAR(100),
    @tExpirTokenAcsso SMALLINT,
    @tExpirTokenAtulz SMALLINT,
    @cSitAplicCanal BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pUpdAplicCliCanal01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @wChaveSecrtCript,
            @tExpirTokenAcsso,
            @tExpirTokenAtulz,
            @cSitAplicCanal;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pUpdAplicCliCanal01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal08]    Script Date: 16/02/2022 19:04:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal08]
(
    @dbVersion INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal08',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal08] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz06]    Script Date: 16/02/2022 19:04:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz06]
(
    @dbVersion INTEGER,
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz05]    Script Date: 16/02/2022 19:04:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz05]
(
    @dbVersion INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz04]    Script Date: 16/02/2022 19:04:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz04]
(
    @dbVersion INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz03]    Script Date: 16/02/2022 19:04:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitPrfilAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cSitPrfilAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz02]    Script Date: 16/02/2022 19:04:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz02]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli05]    Script Date: 16/02/2022 19:04:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli05]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli04]    Script Date: 16/02/2022 19:04:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli04]
(
    @dbVersion INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli06]    Script Date: 16/02/2022 19:04:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli06]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli03]    Script Date: 16/02/2022 19:04:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli02]    Script Date: 16/02/2022 19:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli02]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelPrfilAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken06]    Script Date: 16/02/2022 19:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken06]
(
    @dbVersion INTEGER,
    @iMtodoGeracToken CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken05]    Script Date: 16/02/2022 19:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken05]
(
    @dbVersion INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken04]    Script Date: 16/02/2022 19:04:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken04]
(
    @dbVersion INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken03]    Script Date: 16/02/2022 19:04:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitTokenAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
        @cMidia,
        @cAplicCliServdAutrz,
        @cSitTokenAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken02]    Script Date: 16/02/2022 19:04:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken02]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
        @cMidia,
        @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken01]    Script Date: 16/02/2022 19:04:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelMtodoGeracToken01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli05]    Script Date: 16/02/2022 19:04:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli05]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli04]    Script Date: 16/02/2022 19:04:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli04]
(
    @dbVersion INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli06]    Script Date: 16/02/2022 19:04:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli06]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli03]    Script Date: 16/02/2022 19:04:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli02]    Script Date: 16/02/2022 19:04:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli02]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli01]    Script Date: 16/02/2022 19:04:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelGeracTokenAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz06]    Script Date: 16/02/2022 19:04:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz06]
(
    @dbVersion INTEGER,
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz05]    Script Date: 16/02/2022 19:04:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz05]
(
    @dbVersion INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz03]    Script Date: 16/02/2022 19:04:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitEscpoAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cSitEscpoAplic;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz02]    Script Date: 16/02/2022 19:04:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz02]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz04]    Script Date: 16/02/2022 19:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz04]
(
    @dbVersion INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli05]    Script Date: 16/02/2022 19:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli05]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli03]    Script Date: 16/02/2022 19:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli03]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli06]    Script Date: 16/02/2022 19:04:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli06]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli04]    Script Date: 16/02/2022 19:04:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli04]
(
    @dbVersion INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli02]    Script Date: 16/02/2022 19:04:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli02]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:04:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelEscpoAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz05]    Script Date: 16/02/2022 19:04:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz05]
(
    @dbVersion INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliServdAutrz05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz04]    Script Date: 16/02/2022 19:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz04]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliServdAutrz04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz03]    Script Date: 16/02/2022 19:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz03]
(
    @dbVersion INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliServdAutrz03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz02]    Script Date: 16/02/2022 19:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliServdAutrz02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz01]    Script Date: 16/02/2022 19:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal06]    Script Date: 16/02/2022 19:04:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal06]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal06',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal06] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal07]    Script Date: 16/02/2022 19:04:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal07]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal07',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal07] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal05]    Script Date: 16/02/2022 19:04:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal05]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitAplicCanal BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal05',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cSitAplicCanal;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal05] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal04]    Script Date: 16/02/2022 19:04:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal04]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal04',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal04] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal03]    Script Date: 16/02/2022 19:04:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal03]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER,
    @cSitAplicCanal BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal03',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz,
            @cSitAplicCanal;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal03] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal02]    Script Date: 16/02/2022 19:04:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal02',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal01]    Script Date: 16/02/2022 19:04:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal01]
(
    @dbVersion INTEGER,
    @pMaxRows TINYINT = 50
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pSelAplicCliCanal01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @pMaxRows;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsPrfilAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsPrfilAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsPrfilAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:04:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsPrfilAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT,
    @cSitPrfilAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsPrfilAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cPrfilAcssoServdAutrz,
            @cSitPrfilAplic
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsPrfilAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsMtodoGeracToken01]    Script Date: 16/02/2022 19:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsMtodoGeracToken01]
(
    @dbVersion INTEGER,
    @iMtodoGeracToken CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsMtodoGeracToken01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsMtodoGeracToken01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsGeracTokenAplicCli01]    Script Date: 16/02/2022 19:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsGeracTokenAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT,
    @cSitTokenAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsGeracTokenAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cMtodoGeracToken,
            @cSitTokenAplic
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsGeracTokenAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsEscpoAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsEscpoAcssoServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsEscpoAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsEscpoAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT,
    @cSitEscpoAplic BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsEscpoAcssoAplicCli01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @cEscpoAcssoServdAutrz,
            @cSitEscpoAplic
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsEscpoAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliServdAutrz01]    Script Date: 16/02/2022 19:04:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsAplicCliServdAutrz01]
(
    @dbVersion INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsAplicCliServdAutrz01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @iAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsAplicCliServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliCanal01]    Script Date: 16/02/2022 19:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsAplicCliCanal01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @wChaveSecrtCript VARCHAR(100),
    @tExpirTokenAcsso SMALLINT,
    @tExpirTokenAtulz SMALLINT,
    @cSitAplicCanal BIT
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsAplicCliCanal01',
    @vSchema VARCHAR(3) = 'pas';
BEGIN
    IF @dbVersion >= 1
    BEGIN
        SET @vProcNameVer = (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
        EXEC @vProcNameVer
            @cMidia,
            @cAplicCliServdAutrz,
            @wChaveSecrtCript,
            @tExpirTokenAcsso,
            @tExpirTokenAtulz,
            @cSitAplicCanal;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pInsAplicCliCanal01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelPrfilAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tPrfilAcssoServdAutrz WHERE cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelPrfilAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoAplicCli02]    Script Date: 16/02/2022 19:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelPrfilAcssoAplicCli02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tPrfilAcssoAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelPrfilAcssoAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelPrfilAcssoAplicCli01]    Script Date: 16/02/2022 19:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelPrfilAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tPrfilAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelPrfilAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelMtodoGeracToken01]    Script Date: 16/02/2022 19:04:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelMtodoGeracToken01]
(
    @dbVersion INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tMtodoGeracToken WHERE cMtodoGeracToken = @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelMtodoGeracToken01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelGeracTokenAplicCli02]    Script Date: 16/02/2022 19:04:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelGeracTokenAplicCli02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tGeracTokenAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelGeracTokenAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelGeracTokenAplicCli01]    Script Date: 16/02/2022 19:04:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelGeracTokenAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tGeracTokenAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cMtodoGeracToken = @cMtodoGeracToken;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelGeracTokenAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoServdAutrz01]    Script Date: 16/02/2022 19:04:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelEscpoAcssoServdAutrz01]
(
    @dbVersion INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tEscpoAcssoServdAutrz WHERE cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelEscpoAcssoServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoAplicCli02]    Script Date: 16/02/2022 19:04:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelEscpoAcssoAplicCli02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tEscpoAcssoAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelEscpoAcssoAplicCli02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelEscpoAcssoAplicCli01]    Script Date: 16/02/2022 19:04:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelEscpoAcssoAplicCli01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tEscpoAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelEscpoAcssoAplicCli01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliServdAutrz01]    Script Date: 16/02/2022 19:04:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelAplicCliServdAutrz01]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tAplicCliServdAutrz WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelAplicCliServdAutrz01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliCanal02]    Script Date: 16/02/2022 19:04:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelAplicCliCanal02]
(
    @dbVersion INTEGER,
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tAplicCliCanal WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelAplicCliCanal02] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pDelAplicCliCanal01]    Script Date: 16/02/2022 19:04:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pDelAplicCliCanal01]
(
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    IF @dbVersion >= 1
    BEGIN
        DELETE dbo.tAplicCliCanal WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz;
    END
    ELSE
    BEGIN
        DECLARE
            @ErrorMessage VARCHAR(255),
            @ErrorSeverity INTEGER,
            @ErrorState INTEGER;

        SET @ErrorMessage = 'This version of Procedure does not exists'
        SET @ErrorSeverity = 10
        SET @ErrorState = 1
        RAISERROR(@ErrorMessage, @ErrorSeverity, @ErrorState);
    END
END

GO

GRANT EXECUTE ON [pas].[pDelAplicCliCanal01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdPrfilAcssoServdAutrz01_v1]
(
    @cPrfilAcssoServdAutrz SMALLINT,
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
BEGIN
    UPDATE dbo.tPrfilAcssoServdAutrz
       SET iPrfilAcssoServdAutrz = @iPrfilAcssoServdAutrz,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz;
END

GO

GRANT EXECUTE ON [pas].[pUpdPrfilAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdPrfilAcssoAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT,
    @cSitPrfilAplic BIT
)
AS
BEGIN
   UPDATE dbo.tPrfilAcssoAplicCli
      SET cSitPrfilAplic = @cSitPrfilAplic,
          hManutReg = CURRENT_TIMESTAMP
    WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
      AND cMidia = @cMidia
      AND cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz;
END

GO

GRANT EXECUTE ON [pas].[pUpdPrfilAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdMtodoGeracToken01_v1]
(
    @cMtodoGeracToken TINYINT,
    @iMtodoGeracToken CHAR(50)
)
AS
BEGIN
    UPDATE dbo.tMtodoGeracToken
       SET iMtodoGeracToken = @iMtodoGeracToken,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cMtodoGeracToken = @cMtodoGeracToken;
END

GO

GRANT EXECUTE ON [pas].[pUpdMtodoGeracToken01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdGeracTokenAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT,
    @cSitTokenAplic BIT
)
AS
BEGIN
    UPDATE dbo.tGeracTokenAplicCli
       SET cSitTokenAplic = @cSitTokenAplic,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
       AND cMidia = @cMidia
       AND cMtodoGeracToken = @cMtodoGeracToken;
END

GO

GRANT EXECUTE ON [pas].[pUpdGeracTokenAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:31 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdEscpoAcssoServdAutrz01_v1]
(
    @cEscpoAcssoServdAutrz SMALLINT,
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
BEGIN
   UPDATE dbo.tEscpoAcssoServdAutrz
      SET iEscpoAcssoServdAutrz = @iEscpoAcssoServdAutrz,
          hManutReg = CURRENT_TIMESTAMP
    WHERE cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz;
END

GO

GRANT EXECUTE ON [pas].[pUpdEscpoAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdEscpoAcssoAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT,
    @cSitEscpoAplic BIT
)
AS
BEGIN
    UPDATE dbo.tEscpoAcssoAplicCli
       SET cSitEscpoAplic = @cSitEscpoAplic,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
       AND cMidia = @cMidia
       AND cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz;
END

GO

GRANT EXECUTE ON [pas].[pUpdEscpoAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:04:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdAplicCliServdAutrz01_v1]
(
    @cAplicCliServdAutrz INTEGER,
    @iAplicCliServdAutrz CHAR(50)
)
AS
BEGIN
    UPDATE dbo.tAplicCliServdAutrz
       SET iAplicCliServdAutrz = @iAplicCliServdAutrz,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz;
END

GO

GRANT EXECUTE ON [pas].[pUpdAplicCliServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pUpdAplicCliCanal01_v1]    Script Date: 16/02/2022 19:04:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pUpdAplicCliCanal01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @wChaveSecrtCript VARCHAR(100),
    @tExpirTokenAcsso SMALLINT,
    @tExpirTokenAtulz SMALLINT,
    @cSitAplicCanal BIT
)
AS
BEGIN
    UPDATE dbo.tAplicCliCanal
       SET wChaveSecrtCript = @wChaveSecrtCript,
           tExpirTokenAcsso = @tExpirTokenAcsso,
           tExpirTokenAtulz = @tExpirTokenAtulz,
           cSitAplicCanal = @cSitAplicCanal,
           hManutReg = CURRENT_TIMESTAMP
     WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
       AND cMidia = @cMidia;
END

GO

GRANT EXECUTE ON [pas].[pUpdAplicCliCanal01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal08_v1]    Script Date: 16/02/2022 19:04:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pas].[pSelAplicCliCanal08_v1]
(
      @iAplicCliServdAutrz CHAR(50)
)
AS
BEGIN
    SELECT aplicCli.tExpirTokenAcsso
    FROM dbo.tAplicCliCanal as aplicCli 
    inner join dbo.tAplicCliServdAutrz as servd on(aplicCli.cAplicCliServdAutrz = servd.cAplicCliServdAutrz)
 	where servd.iAplicCliServdAutrz = @iAplicCliServdAutrz;

END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal08_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz06_v1]    Script Date: 16/02/2022 19:04:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz06_v1](
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoServdAutrz WHERE iPrfilAcssoServdAutrz = @iPrfilAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz05_v1]    Script Date: 16/02/2022 19:04:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz05_v1](
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoServdAutrz WHERE cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz04_v1]    Script Date: 16/02/2022 19:04:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz04_v1]
(
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT cPrfilAcssoServdAutrz,
        TRIM(iPrfilAcssoServdAutrz) AS iPrfilAcssoServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tPrfilAcssoServdAutrz
    WHERE cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz03_v1]    Script Date: 16/02/2022 19:04:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz03_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitPrfilAplic BIT
)
AS
BEGIN
    SELECT p.cPrfilAcssoServdAutrz,
        TRIM(p.iPrfilAcssoServdAutrz) AS iPrfilAcssoServdAutrz,
        p.hInclReg,
        p.hManutReg
    FROM dbo.tPrfilAcssoServdAutrz AS p
    INNER JOIN dbo.tPrfilAcssoAplicCli AS pc
        ON p.cPrfilAcssoServdAutrz = pc.cPrfilAcssoServdAutrz
    WHERE pc.cAplicCliServdAutrz = @cAplicCliServdAutrz AND pc.cMidia = @cMidia AND pc.cSitPrfilAplic = @cSitPrfilAplic;
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz02_v1]    Script Date: 16/02/2022 19:04:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz02_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT p.cPrfilAcssoServdAutrz,
        TRIM(p.iPrfilAcssoServdAutrz) AS iPrfilAcssoServdAutrz,
        p.hInclReg,
        p.hManutReg
    FROM dbo.tPrfilAcssoServdAutrz AS p
    INNER JOIN dbo.tPrfilAcssoAplicCli AS pc
        ON p.cPrfilAcssoServdAutrz = pc.cPrfilAcssoServdAutrz
    WHERE pc.cAplicCliServdAutrz = @cAplicCliServdAutrz AND pc.cMidia = @cMidia;
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoServdAutrz01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cPrfilAcssoServdAutrz,
        TRIM(iPrfilAcssoServdAutrz) AS iPrfilAcssoServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tPrfilAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli05_v1]    Script Date: 16/02/2022 19:04:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli05_v1](
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli04_v1]    Script Date: 16/02/2022 19:04:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli04_v1](
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoAplicCli WHERE cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli06_v1]    Script Date: 16/02/2022 19:04:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli06_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cPrfilAcssoServdAutrz = @cPrfilAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli03_v1]    Script Date: 16/02/2022 19:04:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli03_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tPrfilAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli02_v1]    Script Date: 16/02/2022 19:04:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli02_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        pc.cMidia,
        TRIM(c.iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        TRIM(p.iPrfilAcssoServdAutrz) AS iPrfilAcssoServdAutrz,
        pc.cSitPrfilAplic,
        pc.hInclReg,
        pc.hManutReg
    FROM dbo.tPrfilAcssoAplicCli pc
    INNER JOIN dbo.tAplicCliServdAutrz c
    ON pc.cAplicCliServdAutrz = c.cAplicCliServdAutrz
    INNER JOIN dbo.tPrfilAcssoServdAutrz p
    ON pc.cPrfilAcssoServdAutrz = p.cPrfilAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelPrfilAcssoAplicCli01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cMidia,
        cAplicCliServdAutrz,
        cPrfilAcssoServdAutrz,
        cSitPrfilAplic,
        hInclReg,
        hManutReg
    FROM dbo.tPrfilAcssoAplicCli
END

GO

GRANT EXECUTE ON [pas].[pSelPrfilAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken06_v1]    Script Date: 16/02/2022 19:04:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken06_v1](
    @iMtodoGeracToken CHAR(50)
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tMtodoGeracToken WHERE iMtodoGeracToken = @iMtodoGeracToken)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken05_v1]    Script Date: 16/02/2022 19:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken05_v1](
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tMtodoGeracToken WHERE cMtodoGeracToken = @cMtodoGeracToken)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken04_v1]    Script Date: 16/02/2022 19:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken04_v1]
(
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    SELECT cMtodoGeracToken,
        TRIM(iMtodoGeracToken) iMtodoGeracToken,
        hInclReg,
        hManutReg
    FROM dbo.tMtodoGeracToken
    WHERE cMtodoGeracToken = @cMtodoGeracToken
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken03_v1]    Script Date: 16/02/2022 19:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken03_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitTokenAplic BIT
)
AS
BEGIN
    SELECT t.cMtodoGeracToken,
        TRIM(t.iMtodoGeracToken) AS iMtodoGeracToken,
        t.hInclReg,
        t.hManutReg
    FROM dbo.tMtodoGeracToken AS t
    INNER JOIN dbo.tGeracTokenAplicCli AS tc
        ON t.cMtodoGeracToken = tc.cMtodoGeracToken
    WHERE tc.cAplicCliServdAutrz = @cAplicCliServdAutrz AND tc.cMidia = @cMidia AND tc.cSitTokenAplic = @cSitTokenAplic;
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken02_v1]    Script Date: 16/02/2022 19:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken02_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT t.cMtodoGeracToken,
        TRIM(t.iMtodoGeracToken) AS iMtodoGeracToken,
        t.hInclReg,
        t.hManutReg
    FROM dbo.tMtodoGeracToken AS t
    INNER JOIN dbo.tGeracTokenAplicCli AS tc
        ON t.cMtodoGeracToken = tc.cMtodoGeracToken
    WHERE tc.cAplicCliServdAutrz = @cAplicCliServdAutrz AND tc.cMidia = @cMidia;
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelMtodoGeracToken01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cMtodoGeracToken,
        TRIM(iMtodoGeracToken) AS iMtodoGeracToken,
        hInclReg,
        hManutReg
    FROM dbo.tMtodoGeracToken
END

GO

GRANT EXECUTE ON [pas].[pSelMtodoGeracToken01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli05_v1]    Script Date: 16/02/2022 19:04:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli05_v1](
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tGeracTokenAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli04_v1]    Script Date: 16/02/2022 19:04:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli04_v1](
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tGeracTokenAplicCli WHERE cMtodoGeracToken = @cMtodoGeracToken)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli06_v1]    Script Date: 16/02/2022 19:04:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli06_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tGeracTokenAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cMtodoGeracToken = @cMtodoGeracToken)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli03_v1]    Script Date: 16/02/2022 19:04:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli03_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tGeracTokenAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli02_v1]    Script Date: 16/02/2022 19:04:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli02_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        tc.cMidia,
        TRIM(c.iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        TRIM(t.iMtodoGeracToken) AS iMtodoGeracToken,
        tc.cSitTokenAplic,
        tc.hInclReg,
        tc.hManutReg
    FROM dbo.tGeracTokenAplicCli tc
    INNER JOIN dbo.tAplicCliServdAutrz c
    ON tc.cAplicCliServdAutrz = c.cAplicCliServdAutrz
    INNER JOIN dbo.tMtodoGeracToken t
    ON tc.cMtodoGeracToken = t.cMtodoGeracToken
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:04:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelGeracTokenAplicCli01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cMidia,
        cAplicCliServdAutrz,
        cMtodoGeracToken,
        cSitTokenAplic,
        hInclReg,
        hManutReg
    FROM dbo.tGeracTokenAplicCli
END

GO

GRANT EXECUTE ON [pas].[pSelGeracTokenAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz06_v1]    Script Date: 16/02/2022 19:04:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz06_v1](
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoServdAutrz WHERE iEscpoAcssoServdAutrz = @iEscpoAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz05_v1]    Script Date: 16/02/2022 19:04:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz05_v1](
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoServdAutrz WHERE cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz03_v1]    Script Date: 16/02/2022 19:04:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz03_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitEscpoAplic BIT
)
AS
BEGIN
    SELECT e.cEscpoAcssoServdAutrz,
        TRIM(e.iEscpoAcssoServdAutrz) iEscpoAcssoServdAutrz,
        e.hInclReg,
        e.hManutReg
    FROM dbo.tEscpoAcssoServdAutrz AS e
    INNER JOIN dbo.tEscpoAcssoAplicCli AS ec
        ON e.cEscpoAcssoServdAutrz = ec.cEscpoAcssoServdAutrz
    WHERE ec.cAplicCliServdAutrz = @cAplicCliServdAutrz AND ec.cMidia = @cMidia AND ec.cSitEscpoAplic = @cSitEscpoAplic;
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz02_v1]    Script Date: 16/02/2022 19:04:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz02_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT e.cEscpoAcssoServdAutrz,
        TRIM(e.iEscpoAcssoServdAutrz) AS iEscpoAcssoServdAutrz,
        e.hInclReg,
        e.hManutReg
    FROM dbo.tEscpoAcssoServdAutrz AS e
    INNER JOIN dbo.tEscpoAcssoAplicCli AS ec
        ON e.cEscpoAcssoServdAutrz = ec.cEscpoAcssoServdAutrz
    WHERE ec.cAplicCliServdAutrz = @cAplicCliServdAutrz AND ec.cMidia = @cMidia;
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz04_v1]    Script Date: 16/02/2022 19:04:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz04_v1]
(
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT cEscpoAcssoServdAutrz,
        TRIM(iEscpoAcssoServdAutrz) AS iEscpoAcssoServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tEscpoAcssoServdAutrz
    WHERE cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoServdAutrz01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cEscpoAcssoServdAutrz,
        TRIM(iEscpoAcssoServdAutrz) AS iEscpoAcssoServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tEscpoAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli05_v1]    Script Date: 16/02/2022 19:04:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli05_v1](
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoAplicCli WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli06_v1]    Script Date: 16/02/2022 19:04:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli06_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli03_v1]    Script Date: 16/02/2022 19:04:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli03_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoAplicCli WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli04_v1]    Script Date: 16/02/2022 19:04:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli04_v1](
    @cEscpoAcssoServdAutrz SMALLINT
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tEscpoAcssoAplicCli WHERE cEscpoAcssoServdAutrz = @cEscpoAcssoServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli02_v1]    Script Date: 16/02/2022 19:04:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli02_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        ec.cMidia,
        TRIM(c.iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        TRIM(e.iEscpoAcssoServdAutrz) AS iEscpoAcssoServdAutrz,
        ec.cSitEscpoAplic,
        ec.hInclReg,
        ec.hManutReg
    FROM dbo.tEscpoAcssoAplicCli ec
    INNER JOIN dbo.tAplicCliServdAutrz c
    ON ec.cAplicCliServdAutrz = c.cAplicCliServdAutrz
    INNER JOIN dbo.tEscpoAcssoServdAutrz e
    ON ec.cEscpoAcssoServdAutrz = e.cEscpoAcssoServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelEscpoAcssoAplicCli01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cMidia,
        cAplicCliServdAutrz,
        cEscpoAcssoServdAutrz,
        cSitEscpoAplic,
        hInclReg,
        hManutReg
    FROM dbo.tEscpoAcssoAplicCli
END

GO

GRANT EXECUTE ON [pas].[pSelEscpoAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz05_v1]    Script Date: 16/02/2022 19:04:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz05_v1](
    @iAplicCliServdAutrz CHAR(50)
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tAplicCliServdAutrz WHERE iAplicCliServdAutrz = @iAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz04_v1]    Script Date: 16/02/2022 19:04:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz04_v1](
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tAplicCliServdAutrz WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz03_v1]    Script Date: 16/02/2022 19:04:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz03_v1]
(
    @iAplicCliServdAutrz CHAR(50)
)
AS
BEGIN
    SELECT cAplicCliServdAutrz,
        TRIM(iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliServdAutrz
    WHERE iAplicCliServdAutrz = @iAplicCliServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz03_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz02_v1]    Script Date: 16/02/2022 19:04:41 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz02_v1]
(
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT cAplicCliServdAutrz,
        TRIM(iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliServdAutrz
    WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:04:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliServdAutrz01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cAplicCliServdAutrz,
        TRIM(iAplicCliServdAutrz) AS iAplicCliServdAutrz,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal07_v1]    Script Date: 16/02/2022 19:04:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal07_v1](
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tAplicCliCanal WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal07_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal06_v1]    Script Date: 16/02/2022 19:04:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal06_v1](
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT
      	CASE
      		WHEN EXISTS(SELECT 1 FROM dbo.tAplicCliCanal WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz)
      		THEN CAST('TRUE' AS BIT)
      		ELSE CAST('FALSE' AS BIT)
      	END
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal06_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal05_v1]    Script Date: 16/02/2022 19:04:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal05_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cSitAplicCanal BIT
)
AS
BEGIN
    SELECT cMidia,
        cAplicCliServdAutrz,
        wChaveSecrtCript,
        tExpirTokenAcsso,
        tExpirTokenAtulz,
        cSitAplicCanal,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliCanal
    WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz AND cSitAplicCanal = @cSitAplicCanal
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal05_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal04_v1]    Script Date: 16/02/2022 19:04:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal04_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT cMidia,
        cAplicCliServdAutrz,
        wChaveSecrtCript,
        tExpirTokenAcsso,
        tExpirTokenAtulz,
        cSitAplicCanal,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliCanal
    WHERE cMidia = @cMidia AND cAplicCliServdAutrz = @cAplicCliServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal04_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal02_v1]    Script Date: 16/02/2022 19:04:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal02_v1]
(
    @cAplicCliServdAutrz INTEGER
)
AS
BEGIN
    SELECT cMidia,
        cAplicCliServdAutrz,
        wChaveSecrtCript,
        tExpirTokenAcsso,
        tExpirTokenAtulz,
        cSitAplicCanal,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliCanal
    WHERE cAplicCliServdAutrz = @cAplicCliServdAutrz
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal02_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pSelAplicCliCanal01_v1]    Script Date: 16/02/2022 19:04:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pSelAplicCliCanal01_v1]
(
    @pMaxRows TINYINT
)
AS
BEGIN
    SELECT TOP (@pMaxRows)
        cMidia,
        cAplicCliServdAutrz,
        wChaveSecrtCript,
        tExpirTokenAcsso,
        tExpirTokenAtulz,
        cSitAplicCanal,
        hInclReg,
        hManutReg
    FROM dbo.tAplicCliCanal
END

GO

GRANT EXECUTE ON [pas].[pSelAplicCliCanal01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsPrfilAcssoServdAutrz01_v1]
(
    @iPrfilAcssoServdAutrz CHAR(50)
)
AS
BEGIN
    INSERT INTO dbo.tPrfilAcssoServdAutrz
    (
        iPrfilAcssoServdAutrz,
        hInclReg
    )
    VALUES
    (
        @iPrfilAcssoServdAutrz,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsPrfilAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsPrfilAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:43 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsPrfilAcssoAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cPrfilAcssoServdAutrz SMALLINT,
    @cSitPrfilAplic BIT
)
AS
BEGIN
    INSERT INTO dbo.tPrfilAcssoAplicCli
    (
        cMidia,
        cAplicCliServdAutrz,
        cPrfilAcssoServdAutrz,
        cSitPrfilAplic,
        hInclReg
    )
    VALUES
    (
        @cMidia,
        @cAplicCliServdAutrz,
        @cPrfilAcssoServdAutrz,
        @cSitPrfilAplic,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsPrfilAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsMtodoGeracToken01_v1]    Script Date: 16/02/2022 19:04:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsMtodoGeracToken01_v1]
(
    @iMtodoGeracToken CHAR(50)
)
AS
BEGIN
    INSERT INTO dbo.tMtodoGeracToken
    (
        iMtodoGeracToken,
        hInclReg
    )
    VALUES
    (
        @iMtodoGeracToken,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsMtodoGeracToken01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsGeracTokenAplicCli01_v1]    Script Date: 16/02/2022 19:04:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsGeracTokenAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cMtodoGeracToken TINYINT,
    @cSitTokenAplic BIT
)
AS
BEGIN
    INSERT INTO dbo.tGeracTokenAplicCli
    (
        cMidia,
        cAplicCliServdAutrz,
        cMtodoGeracToken,
        cSitTokenAplic,
        hInclReg
    )
    VALUES
    (
        @cMidia,
        @cAplicCliServdAutrz,
        @cMtodoGeracToken,
        @cSitTokenAplic,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsGeracTokenAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoServdAutrz01_v1]    Script Date: 16/02/2022 19:04:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsEscpoAcssoServdAutrz01_v1]
(
    @iEscpoAcssoServdAutrz CHAR(50)
)
AS
BEGIN
    INSERT INTO dbo.tEscpoAcssoServdAutrz
    (
        iEscpoAcssoServdAutrz,
        hInclReg
    )
    VALUES
    (
        @iEscpoAcssoServdAutrz,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsEscpoAcssoServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsEscpoAcssoAplicCli01_v1]    Script Date: 16/02/2022 19:04:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsEscpoAcssoAplicCli01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @cEscpoAcssoServdAutrz SMALLINT,
    @cSitEscpoAplic BIT
)
AS
BEGIN
    INSERT INTO dbo.tEscpoAcssoAplicCli
    (
        cMidia,
        cAplicCliServdAutrz,
        cEscpoAcssoServdAutrz,
        cSitEscpoAplic,
        hInclReg
    )
    VALUES
    (
        @cMidia,
        @cAplicCliServdAutrz,
        @cEscpoAcssoServdAutrz,
        @cSitEscpoAplic,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsEscpoAcssoAplicCli01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliServdAutrz01_v1]    Script Date: 16/02/2022 19:04:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsAplicCliServdAutrz01_v1]
(
    @iAplicCliServdAutrz CHAR(50)
)
AS
BEGIN
    INSERT INTO dbo.tAplicCliServdAutrz
    (
        iAplicCliServdAutrz,
        hInclReg
    )
    VALUES
    (
        @iAplicCliServdAutrz,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsAplicCliServdAutrz01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pas].[pInsAplicCliCanal01_v1]    Script Date: 16/02/2022 19:04:45 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pas].[pInsAplicCliCanal01_v1]
(
    @cMidia DECIMAL(3),
    @cAplicCliServdAutrz INTEGER,
    @wChaveSecrtCript VARCHAR(100),
    @tExpirTokenAcsso SMALLINT,
    @tExpirTokenAtulz SMALLINT,
    @cSitAplicCanal BIT
)
AS
BEGIN
    INSERT INTO dbo.tAplicCliCanal
    (
        cMidia,
        cAplicCliServdAutrz,
        wChaveSecrtCript,
        tExpirTokenAcsso,
        tExpirTokenAtulz,
        cSitAplicCanal,
        hInclReg
    )
    VALUES
    (
        @cMidia,
        @cAplicCliServdAutrz,
        @wChaveSecrtCript,
        @tExpirTokenAcsso,
        @tExpirTokenAtulz,
        @cSitAplicCanal,
        CURRENT_TIMESTAMP
    )
END

GO

GRANT EXECUTE ON [pas].[pInsAplicCliCanal01_v1] TO [APLICATIVOS] AS [dbo]
GO


