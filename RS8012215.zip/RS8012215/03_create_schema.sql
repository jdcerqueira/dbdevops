IF (NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'pas')) 
BEGIN
    EXEC ('CREATE SCHEMA [pas] AUTHORIZATION [dbo]')
END
GO
