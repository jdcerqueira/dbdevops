IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'Aplicativos' AND type = 'R')
CREATE ROLE [Aplicativos] AUTHORIZATION [dbo]
GO

--ATENÇÃO: ALTERAR O NOME DO USUÁRIO, CONFORME OS AMBIENTES DE HO OU PRO

IF (NOT EXISTS (SELECT * FROM sysusers WHERE name = 'pusrbdpdpj01')) 
BEGIN
	CREATE USER pusrbdpdpj01 FOR LOGIN pusrbdpdpj01
END
GO

EXEC dbo.sp_addrolemember @rolename=N'Aplicativos', @membername=N'pusrbdpdpj01'
GO

GRANT EXECUTE TO APLICATIVOS
go

