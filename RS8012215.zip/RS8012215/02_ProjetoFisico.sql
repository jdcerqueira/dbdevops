CREATE TABLE [tAplicCliCanal]
( 
	[cAplicCliServdAutrz] integer  NOT NULL ,
	[cMidia]             decimal(3)  NOT NULL ,
	[wChaveSecrtCript]   varchar(100)  NULL ,
	[tExpirTokenAcsso]   smallint  NOT NULL ,
	[tExpirTokenAtulz]   smallint  NOT NULL ,
	[cSitAplicCanal]     bit  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tAplicCliCanal]
	ADD CONSTRAINT [XPKtAplicCliCanal] PRIMARY KEY  CLUSTERED ([cAplicCliServdAutrz] ASC,[cMidia] ASC)
go

CREATE TABLE [tAplicCliServdAutrz]
( 
	[cAplicCliServdAutrz] integer  NOT NULL  IDENTITY ( 1,1 ) ,
	[iAplicCliServdAutrz] varchar(50)  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tAplicCliServdAutrz]
	ADD CONSTRAINT [XPKtAplicCliServdAutrz] PRIMARY KEY  CLUSTERED ([cAplicCliServdAutrz] ASC)
go

ALTER TABLE [tAplicCliServdAutrz]
	ADD CONSTRAINT [XAK1tAplicCliServdAutrz] UNIQUE ([iAplicCliServdAutrz]  ASC)
go

CREATE TABLE [tEscpoAcssoAplicCli]
( 
	[cAplicCliServdAutrz] integer  NOT NULL ,
	[cMidia]             decimal(3)  NOT NULL ,
	[cEscpoAcssoServdAutrz] smallint  NOT NULL ,
	[cSitEscpoAplic]     bit  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tEscpoAcssoAplicCli]
	ADD CONSTRAINT [XPKtEscpoAcssoAplicCli] PRIMARY KEY  CLUSTERED ([cAplicCliServdAutrz] ASC,[cMidia] ASC,[cEscpoAcssoServdAutrz] ASC)
go

CREATE NONCLUSTERED INDEX [XIF2tEscpoAcssoAplicCli] ON [tEscpoAcssoAplicCli]
( 
	[cEscpoAcssoServdAutrz]  ASC
)
go

CREATE TABLE [tEscpoAcssoServdAutrz]
( 
	[cEscpoAcssoServdAutrz] smallint  NOT NULL  IDENTITY ( 1,1 ) ,
	[iEscpoAcssoServdAutrz] varchar(50)  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tEscpoAcssoServdAutrz]
	ADD CONSTRAINT [XPKtEscpoAcssoServdAutrz] PRIMARY KEY  CLUSTERED ([cEscpoAcssoServdAutrz] ASC)
go

ALTER TABLE [tEscpoAcssoServdAutrz]
	ADD CONSTRAINT [XAK1tEscpoAcssoServdAutrz] UNIQUE ([iEscpoAcssoServdAutrz]  ASC)
go

CREATE TABLE [tGeracTokenAplicCli]
( 
	[cAplicCliServdAutrz] integer  NOT NULL ,
	[cMidia]             decimal(3)  NOT NULL ,
	[cMtodoGeracToken]   tinyint  NOT NULL ,
	[cSitTokenAplic]     bit  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tGeracTokenAplicCli]
	ADD CONSTRAINT [XPKtGeracTokenAplicCli] PRIMARY KEY  CLUSTERED ([cAplicCliServdAutrz] ASC,[cMidia] ASC,[cMtodoGeracToken] ASC)
go

CREATE NONCLUSTERED INDEX [XIF2tGeracTokenAplicCli] ON [tGeracTokenAplicCli]
( 
	[cMtodoGeracToken]    ASC
)
go

CREATE TABLE [tMtodoGeracToken]
( 
	[cMtodoGeracToken]   tinyint  NOT NULL  IDENTITY ( 1,1 ) ,
	[iMtodoGeracToken]   varchar(50)  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tMtodoGeracToken]
	ADD CONSTRAINT [XPKtMtodoGeracToken] PRIMARY KEY  CLUSTERED ([cMtodoGeracToken] ASC)
go

ALTER TABLE [tMtodoGeracToken]
	ADD CONSTRAINT [XAK1tMtodoGeracToken] UNIQUE ([iMtodoGeracToken]  ASC)
go

CREATE TABLE [tPrfilAcssoAplicCli]
( 
	[cAplicCliServdAutrz] integer  NOT NULL ,
	[cMidia]             decimal(3)  NOT NULL ,
	[cPrfilAcssoServdAutrz] smallint  NOT NULL ,
	[cSitPrfilAplic]     bit  NOT NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tPrfilAcssoAplicCli]
	ADD CONSTRAINT [XPKtPrfilAcssoAplicCli] PRIMARY KEY  CLUSTERED ([cAplicCliServdAutrz] ASC,[cMidia] ASC,[cPrfilAcssoServdAutrz] ASC)
go

CREATE NONCLUSTERED INDEX [XIF2tPrfilAcssoAplicCli] ON [tPrfilAcssoAplicCli]
( 
	[cPrfilAcssoServdAutrz]  ASC
)
go

CREATE TABLE [tPrfilAcssoServdAutrz]
( 
	[cPrfilAcssoServdAutrz] smallint  NOT NULL  IDENTITY ( 1,1 ) ,
	[iPrfilAcssoServdAutrz] varchar(50)  NULL ,
	[hInclReg]           datetime  NOT NULL ,
	[hManutReg]          datetime  NULL 
)
go

ALTER TABLE [tPrfilAcssoServdAutrz]
	ADD CONSTRAINT [XPKtPrfilAcssoServdAutrz] PRIMARY KEY  CLUSTERED ([cPrfilAcssoServdAutrz] ASC)
go

ALTER TABLE [tPrfilAcssoServdAutrz]
	ADD CONSTRAINT [XAK1tPrfilAcssoServdAutrz] UNIQUE ([iPrfilAcssoServdAutrz]  ASC)
go


ALTER TABLE [tAplicCliCanal]
	ADD CONSTRAINT [FKtAplicCliServdAutrz01] FOREIGN KEY ([cAplicCliServdAutrz]) REFERENCES [tAplicCliServdAutrz]([cAplicCliServdAutrz])
go


ALTER TABLE [tEscpoAcssoAplicCli]
	ADD CONSTRAINT [FKtAplicCliCanal03] FOREIGN KEY ([cAplicCliServdAutrz],[cMidia]) REFERENCES [tAplicCliCanal]([cAplicCliServdAutrz],[cMidia])
go

ALTER TABLE [tEscpoAcssoAplicCli]
	ADD CONSTRAINT [FKtEscpoAcssoServdAutrz01] FOREIGN KEY ([cEscpoAcssoServdAutrz]) REFERENCES [tEscpoAcssoServdAutrz]([cEscpoAcssoServdAutrz])
go


ALTER TABLE [tGeracTokenAplicCli]
	ADD CONSTRAINT [FKtAplicCliCanal01] FOREIGN KEY ([cAplicCliServdAutrz],[cMidia]) REFERENCES [tAplicCliCanal]([cAplicCliServdAutrz],[cMidia])
go

ALTER TABLE [tGeracTokenAplicCli]
	ADD CONSTRAINT [FKtMtodoGeracToken01] FOREIGN KEY ([cMtodoGeracToken]) REFERENCES [tMtodoGeracToken]([cMtodoGeracToken])
go


ALTER TABLE [tPrfilAcssoAplicCli]
	ADD CONSTRAINT [FKtAplicCliCanal02] FOREIGN KEY ([cAplicCliServdAutrz],[cMidia]) REFERENCES [tAplicCliCanal]([cAplicCliServdAutrz],[cMidia])
go

ALTER TABLE [tPrfilAcssoAplicCli]
	ADD CONSTRAINT [FKtPrfilAcssoServdAutrz01] FOREIGN KEY ([cPrfilAcssoServdAutrz]) REFERENCES [tPrfilAcssoServdAutrz]([cPrfilAcssoServdAutrz])
go
