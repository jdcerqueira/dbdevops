USE PDPJD006
GO

--Criar parti��o
IF EXISTS (SELECT * FROM sys.partition_functions WHERE [name] = 'fParticaoLogica')
	DROP PARTITION FUNCTION fParticaoLogica
GO

CREATE PARTITION FUNCTION fParticaoLogica (int) AS RANGE LEFT FOR VALUES (0,1,2,3,4,5)
GO

--Criar scheme
IF EXISTS (SELECT * FROM sys.partition_schemes WHERE [name] = 'schParticaoLogica')
	DROP PARTITION SCHEME schParticaoLogica
GO

CREATE PARTITION SCHEME schParticaoLogica
AS PARTITION fParticaoLogica
TO ([PRIMARY],[PRIMARY],[PRIMARY],[PRIMARY],[PRIMARY],[PRIMARY],[PRIMARY])
GO

