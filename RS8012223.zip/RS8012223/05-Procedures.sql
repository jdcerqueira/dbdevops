USE [PDPJD006]
GO

/****** Object:  StoredProcedure [monitoramento].[pInsTSessPlatfPj01]    Script Date: 16/02/2022 19:25:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[monitoramento].[pInsTSessPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [monitoramento].[pInsTSessPlatfPj01]
GO

/****** Object:  StoredProcedure [monitoramento].[pInsTSessPlatfPj01_v1]    Script Date: 16/02/2022 19:25:16 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[monitoramento].[pInsTSessPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [monitoramento].[pInsTSessPlatfPj01_v1]
GO


/****** Object:  StoredProcedure [monitoramento].[pInsTSessPlatfPj01_v1]    Script Date: 16/02/2022 19:25:00 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
PROCEDURE: monitoramento.pInsTSessPlatfPj01_v1
PROPOSITO: Grava um novo registro nas tabelas tSessPlatfPj e tEvntoSessPlatfPj
DATA: 04-08-2021
AUTOR: CAPCO
*/

CREATE PROCEDURE [monitoramento].[pInsTSessPlatfPj01_v1](
    @cMidia DECIMAL(3),
    @cBco DECIMAL(3),
    @cAgBcria DECIMAL(5),
    @cTpoDspvoSegrc DECIMAL(3),
    @nCtaCorr int,
    @iRzScialPlatfPj VARCHAR(120),
    @iUsuarPlatfPj VARCHAR(120),
    @eIpSessCli VARCHAR(40),
    @nPortaTcpipAplic int,
    @iAgteUsuar VARCHAR(400),
    @cVrsaoAplicPlatfPj CHAR(10),
    @cVirtuDspvoCli VARCHAR(64),
    @cCtrlSessPlatfPj VARCHAR(80),
    @cSerieChaveDnamc DECIMAL(15),
    @dCriacSessPlatfPj DATETIME,
    @iAplicCliServdAutrz VARCHAR(50),
    @nCnpjEmprPlatfPj DECIMAL(9),
    @nFlialCnpjPlatfPj DECIMAL(4),
    @nCtrlCnpjPlatfPj DECIMAL(2),
    @nCpfUsuarPlatfPj DECIMAL(9),
    @nCtrlCpfUsuarPlatfPj DECIMAL(2),
    @cEvntoSess decimal(1)
)
AS
BEGIN

    BEGIN
        TRANSACTION;

    BEGIN TRY

        DECLARE @newSess INT = 1;
        DECLARE @nSessPlatfPj int = (SELECT nSessPlatfPj FROM [dbo].[tSessPlatfPj] WHERE cCtrlSessPlatfPj = @cCtrlSessPlatfPj);

        IF @nSessPlatfPj IS NULL
            SET @nSessPlatfPj = NEXT VALUE FOR [dbo].[sqSessPlatfPj]
        ELSE
            SET @newSess = 0

        DECLARE @cIndcdPtcao int = @nSessPlatfPj % 6;

        IF @newSess = 1
            BEGIN
                INSERT INTO dbo.tSessPlatfPj
                (nSessPlatfPj,
                 cIndcdPtcao,
                 cMidia,
                 cBco,
                 cAgBcria,
                 cTpoDspvoSegrc,
                 nCtaCorr,
                 iRzScialPlatfPj,
                 iUsuarPlatfPj,
                 eIpSessCli,
                 nPortaTcpipAplic,
                 iAgteUsuar,
                 cVrsaoAplicPlatfPj,
                 cVirtuDspvoCli,
                 cCtrlSessPlatfPj,
                 cSerieChaveDnamc,
                 dCriacSessPlatfPj,
                 iAplicCliServdAutrz,
                 nCnpjEmprPlatfPj,
                 nFlialCnpjPlatfPj,
                 nCtrlCnpjPlatfPj,
                 nCpfUsuarPlatfPj,
                 nCtrlCpfUsuarPlatfPj)
                VALUES (@nSessPlatfPj,
                        @cIndcdPtcao,
                        @cMidia,
                        @cBco,
                        @cAgBcria,
                        @cTpoDspvoSegrc,
                        @nCtaCorr,
                        @iRzScialPlatfPj,
                        @iUsuarPlatfPj,
                        @eIpSessCli,
                        @nPortaTcpipAplic,
                        @iAgteUsuar,
                        @cVrsaoAplicPlatfPj,
                        @cVirtuDspvoCli,
                        @cCtrlSessPlatfPj,
                        @cSerieChaveDnamc,
                        @dCriacSessPlatfPj,
                        @iAplicCliServdAutrz,
                        @nCnpjEmprPlatfPj,
                        @nFlialCnpjPlatfPj,
                        @nCtrlCnpjPlatfPj,
                        @nCpfUsuarPlatfPj,
                        @nCtrlCpfUsuarPlatfPj)
            END

        BEGIN
            INSERT INTO [dbo].[tEvntoSessPlatfPj]
            (nSessPlatfPj,
             cIndcdPtcao,
             dEvntoSessCli,
             cEvntoSess)
            VALUES (@nSessPlatfPj,
                    @cIndcdPtcao,
                    @dCriacSessPlatfPj,
                    @cEvntoSess)
        END

        IF @@TRANCOUNT > 0
            COMMIT TRANSACTION

    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;
    END CATCH;

END


GO

GRANT EXECUTE ON [monitoramento].[pInsTSessPlatfPj01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [monitoramento].[pInsTSessPlatfPj01]    Script Date: 16/02/2022 19:25:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



/*
PROCEDURE: monitoramento.pInsTSessPlatfPj01
PROPOSITO: Valida a vers�o da procedure e a executa para gravar um novo registro nas tabelas tSessPlatfPj e tEvntoSessPlatfPj
DATA: 04-08-2021
AUTOR: CAPCO
*/

CREATE PROCEDURE [monitoramento].[pInsTSessPlatfPj01](
    @dbVersion INTEGER,
    @cMidia DECIMAL(3),
    @cBco DECIMAL(3),
    @cAgBcria DECIMAL(5),
    @cTpoDspvoSegrc DECIMAL(3),
    @nCtaCorr int,
    @iRzScialPlatfPj VARCHAR(120),
    @iUsuarPlatfPj VARCHAR(120),
    @eIpSessCli VARCHAR(40),
    @nPortaTcpipAplic int,
    @iAgteUsuar VARCHAR(400),
    @cVrsaoAplicPlatfPj CHAR(10),
    @cVirtuDspvoCli VARCHAR(64),
    @cCtrlSessPlatfPj VARCHAR(80),
    @cSerieChaveDnamc DECIMAL(15),
    @dCriacSessPlatfPj DATETIME,
    @iAplicCliServdAutrz VARCHAR(50),
    @nCnpjEmprPlatfPj DECIMAL(9),
    @nFlialCnpjPlatfPj DECIMAL(4),
    @nCtrlCnpjPlatfPj DECIMAL(2),
    @nCpfUsuarPlatfPj DECIMAL(9),
    @nCtrlCpfUsuarPlatfPj DECIMAL(2),
    @cEvntoSess decimal(1)
)
AS
DECLARE
    @vProcNameVer VARCHAR(100) = 'pInsTSessPlatfPj01',
    @vSchema      VARCHAR(13)  = 'monitoramento';
BEGIN
    IF @dbVersion >= 1
        BEGIN
            SET @vProcNameVer =
                    (SELECT @vSchema + '.' + @vProcNameVer + '_v' + CAST(@dbVersion AS VARCHAR));
            EXEC @vProcNameVer
                 @cMidia,
                 @cBco,
                 @cAgBcria,
                 @cTpoDspvoSegrc,
                 @nCtaCorr,
                 @iRzScialPlatfPj,
                 @iUsuarPlatfPj,
                 @eIpSessCli,
                 @nPortaTcpipAplic,
                 @iAgteUsuar,
                 @cVrsaoAplicPlatfPj,
                 @cVirtuDspvoCli,
                 @cCtrlSessPlatfPj,
                 @cSerieChaveDnamc,
                 @dCriacSessPlatfPj,
                 @iAplicCliServdAutrz,
                 @nCnpjEmprPlatfPj,
                 @nFlialCnpjPlatfPj,
                 @nCtrlCnpjPlatfPj,
                 @nCpfUsuarPlatfPj,
                 @nCtrlCpfUsuarPlatfPj,
                 @cEvntoSess;
        END
    ELSE
        BEGIN
            DECLARE
                @ErrorMessage VARCHAR(255),
                @ErrorSeverity INTEGER,
                @ErrorState INTEGER;

            SET @ErrorMessage = 'This version of Procedure does not exists'
            SET @ErrorSeverity = 10
            SET @ErrorState = 1
            RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);
        END
END



GO

GRANT EXECUTE ON [monitoramento].[pInsTSessPlatfPj01] TO [APLICATIVOS] AS [dbo]
GO


