CREATE SEQUENCE [sqSessPlatfPj] AS bigint
START WITH 1
INCREMENT BY 1
CYCLE
CACHE 500
go

CREATE SEQUENCE [sqTransPlatfPj] AS bigint
START WITH 1
INCREMENT BY 1
CYCLE
CACHE 500
go

CREATE TABLE [tEvntoSessPlatfPj]
( 
	[nSessPlatfPj]       bigint  NOT NULL ,
	[cIndcdPtcao]        integer  NOT NULL ,
	[dEvntoSessCli]      datetime  NOT NULL ,
	[cEvntoSess]         decimal(1)  NOT NULL 
)
go

ALTER TABLE [tEvntoSessPlatfPj]
	ADD CONSTRAINT [XPKtEvntoSessPlatfPj] PRIMARY KEY  CLUSTERED ([nSessPlatfPj] ASC,[cIndcdPtcao] ASC,[dEvntoSessCli] ASC)
go

CREATE TABLE [tSessPlatfPj]
( 
	[nSessPlatfPj]       bigint  NOT NULL ,
	[cIndcdPtcao]        integer  NOT NULL ,
	[cMidia]             decimal(3)  NOT NULL ,
	[cBco]               decimal(3)  NULL ,
	[cAgBcria]           decimal(5)  NULL ,
	[cTpoDspvoSegrc]     decimal(3)  NULL ,
	[nCtaCorr]           integer  NULL ,
	[iRzScialPlatfPj]    varchar(120)  NULL ,
	[iUsuarPlatfPj]      varchar(120)  NULL ,
	[eIpSessCli]         varchar(40)  NOT NULL ,
	[nPortaTcpipAplic]   integer  NOT NULL ,
	[iAgteUsuar]         varchar(400)  NOT NULL ,
	[cVrsaoAplicPlatfPj] char(10)  NOT NULL ,
	[cVirtuDspvoCli]     varchar(64)  NOT NULL ,
	[cCtrlSessPlatfPj]   varchar(100)  NOT NULL ,
	[cSerieChaveDnamc]   decimal(15)  NOT NULL ,
	[dCriacSessPlatfPj]  datetime  NOT NULL ,
	[iAplicCliServdAutrz] varchar(50)  NOT NULL ,
	[nCnpjEmprPlatfPj]   decimal(9)  NULL ,
	[nFlialCnpjPlatfPj]  decimal(4)  NULL ,
	[nCtrlCnpjPlatfPj]   decimal(2)  NULL ,
	[nCpfUsuarPlatfPj]   decimal(9)  NULL ,
	[nCtrlCpfUsuarPlatfPj] decimal(2)  NULL 
)
go

ALTER TABLE [tSessPlatfPj]
	ADD CONSTRAINT [XPKtSessPlatfPj] PRIMARY KEY  CLUSTERED ([nSessPlatfPj] ASC,[cIndcdPtcao] ASC)
go

CREATE NONCLUSTERED INDEX [XIF1tSessPlatfPj] ON [tSessPlatfPj]
( 
	[cMidia]              ASC
)
go

CREATE NONCLUSTERED INDEX [XIF2tSessPlatfPj] ON [tSessPlatfPj]
( 
	[cAgBcria]            ASC,
	[cBco]                ASC
)
go

CREATE NONCLUSTERED INDEX [XIF3tSessPlatfPj] ON [tSessPlatfPj]
( 
	[cTpoDspvoSegrc]      ASC
)
go

ALTER TABLE [tSessPlatfPj]
	ADD CONSTRAINT [dfSessPlatfPj]
		 DEFAULT  NEXT VALUE FOR sqSessPlatfPj FOR [nSessPlatfPj]
go

ALTER TABLE [tEvntoSessPlatfPj]  
	ADD  CONSTRAINT [FKtSessPlatfPj02] FOREIGN KEY([nSessPlatfPj], [cIndcdPtcao]) REFERENCES [dbo].[tSessPlatfPj] ([nSessPlatfPj], [cIndcdPtcao])
GO

