USE [PDPJD006]
GO

/******** INDICES PRIMARY KEY CLUSTERED********/

--Incuir partionamento na tabela
IF (OBJECT_ID('dbo.XPKtEvntoSessPlatfPj', 'PK') IS NOT NULL)
BEGIN
    ALTER TABLE [dbo].[tEvntoSessPlatfPj] DROP CONSTRAINT XPKtEvntoSessPlatfPj
	ALTER TABLE [dbo].[tEvntoSessPlatfPj] DROP CONSTRAINT FKtSessPlatfPj02
END

IF (OBJECT_ID('dbo.XPKtSessPlatfPj', 'PK') IS NOT NULL)
BEGIN
    ALTER TABLE [dbo].[tSessPlatfPj] DROP CONSTRAINT XPKtSessPlatfPj
END

--tSessPlatfPj

ALTER TABLE [dbo].[tSessPlatfPj] 
ADD CONSTRAINT [XPKtSessPlatfPj] PRIMARY KEY CLUSTERED 
(
	[nSessPlatfPj] ASC,
	[cIndcdPtcao] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
ON schParticaoLogica(cIndcdPtcao) 
GO

--tEvntoSessPlatfPj
ALTER TABLE [dbo].[tEvntoSessPlatfPj]
ADD CONSTRAINT [XPKtEvntoSessPlatfPj] PRIMARY KEY CLUSTERED 
(
	[nSessPlatfPj] ASC,
	[cIndcdPtcao] ASC,
	[dEvntoSessCli] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
ON schParticaoLogica(cIndcdPtcao) 
GO

ALTER TABLE [dbo].[tEvntoSessPlatfPj] ADD CONSTRAINT FKtSessPlatfPj02 FOREIGN KEY ([nSessPlatfPj],[cIndcdPtcao]) REFERENCES [dbo].[tSessPlatfPj] ([nSessPlatfPj],[cIndcdPtcao])

/******** INDICES NONCLUSTEREDS********/

--tSessPlatfPj

/****** Object:  Index [XIF1tSessPlatfPj]    Script Date: 10/08/2021 16:00:40 ******/
IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('dbo.tSessPlatfPj') AND name = 'XIF1tSessPlatfPj')
          DROP INDEX dbo.tSessPlatfPj.XIF1tSessPlatfPj;

CREATE NONCLUSTERED INDEX [XIF1tSessPlatfPj] ON [dbo].[tSessPlatfPj]
(
	[cMidia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
ON schParticaoLogica(cIndcdPtcao)
GO

/****** Object:  Index [XIF2tSessPlatfPj]    Script Date: 10/08/2021 16:02:31 ******/
IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('dbo.tSessPlatfPj') AND name = 'XIF2tSessPlatfPj')
          DROP INDEX dbo.tSessPlatfPj.XIF2tSessPlatfPj;

CREATE NONCLUSTERED INDEX [XIF2tSessPlatfPj] ON [dbo].[tSessPlatfPj]
(
	[cAgBcria] ASC,
	[cBco] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
ON schParticaoLogica(cIndcdPtcao)
GO

/****** Object:  Index [XIF3tSessPlatfPj]    Script Date: 10/08/2021 16:05:36 ******/
IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('dbo.tSessPlatfPj') AND name = 'XIF3tSessPlatfPj')
          DROP INDEX dbo.tSessPlatfPj.XIF3tSessPlatfPj;

CREATE NONCLUSTERED INDEX [XIF3tSessPlatfPj] ON [dbo].[tSessPlatfPj]
(
	[cTpoDspvoSegrc] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
ON schParticaoLogica(cIndcdPtcao)
GO

/****** Object:  Index [XIF4tSessPlatfPj]    Script Date: 06/08/2021 14:01:45 ******/
IF EXISTS (SELECT * FROM sys.indexes WHERE OBJECT_ID = OBJECT_ID('dbo.tSessPlatfPj') AND name = 'XIF4tSessPlatfPj')
          DROP INDEX dbo.tSessPlatfPj.XIF4tSessPlatfPj;

CREATE NONCLUSTERED INDEX [XIF4tSessPlatfPj] ON [dbo].[tSessPlatfPj]
(
	[cCtrlSessPlatfPj] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
ON schParticaoLogica(cIndcdPtcao)
GO


