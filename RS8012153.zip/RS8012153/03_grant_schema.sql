IF USER_ID('Aplicativos') IS NOT NULL
	BEGIN
		ALTER AUTHORIZATION ON SCHEMA::[pes] TO [dbo];

		GRANT EXECUTE ON SCHEMA::[pes] TO [Aplicativos];
	END
GO
