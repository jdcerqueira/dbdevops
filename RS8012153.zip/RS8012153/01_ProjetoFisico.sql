CREATE SEQUENCE [sqUsuarPlatfPj] AS int
START WITH 1
INCREMENT BY 1
CYCLE
NO CACHE
go

 

CREATE SEQUENCE [sqEmprPlatfPj] AS int
START WITH 1
INCREMENT BY 1
CYCLE
NO CACHE
go



CREATE TABLE [tAceitNotifUsuarPj]
( 
	[cUsuarPlatfPj]      integer  NOT NULL ,
	[cTpoNotifUsuar]     smallint  NOT NULL ,
	[dAceitNotifUsuar]   datetime  NOT NULL 
)
go

ALTER TABLE [tAceitNotifUsuarPj]
	ADD CONSTRAINT [XPKtAceitNotifUsuarPj] PRIMARY KEY  CLUSTERED ([cUsuarPlatfPj] ASC,[cTpoNotifUsuar] ASC)
go

CREATE TABLE [tCntatUsuarPlatfPj]
( 
	[cUsuarPlatfPj]      integer  NOT NULL ,
	[cTpoCntatUsuar]     smallint  NOT NULL ,
	[rCntatUsuarPlatfPj] varchar(128)  NOT NULL 
)
go

ALTER TABLE [tCntatUsuarPlatfPj]
	ADD CONSTRAINT [XPKtCntatUsuarPlatfPj] PRIMARY KEY  CLUSTERED ([cUsuarPlatfPj] ASC,[cTpoCntatUsuar] ASC)
go

CREATE TABLE [tEmprPlatfPj]
( 
	[cEmprPlatfPj]       integer  NOT NULL ,
	[nCnpjEmprPlatfPj]   decimal(9)  NOT NULL ,
	[nFlialCnpjPlatfPj]  decimal(4)  NOT NULL ,
	[nCtrlCnpjPlatfPj]   decimal(2)  NOT NULL ,
	[iRzScialPlatfPj]    varchar(120)  NOT NULL ,
	[dCadEmprPlatfPj]    datetime  NOT NULL ,
	[iFantsEmprPlatfPj]  varchar(120)  NULL 
)
go

ALTER TABLE [tEmprPlatfPj]
	ADD CONSTRAINT [XPKtEmprPlatfPj] PRIMARY KEY  CLUSTERED ([cEmprPlatfPj] ASC)
go

CREATE TABLE [tTermoAceit]
( 
	[cTermoAceitPlatfPj] smallint  NOT NULL ,
	[nVrsaoTermoAceit]   smallint  NOT NULL ,
	[cTpoTermoAceit]     smallint  NOT NULL ,
	[rTermoAceitPlatfPj] varchar(255)  NOT NULL ,
	[dFimVgciaTermoAceit] date  NULL ,
	[dInicVgciaTermoAceit] datetime  NOT NULL 
)
go

ALTER TABLE [tTermoAceit]
	ADD CONSTRAINT [XPKtTermoAceit] PRIMARY KEY  CLUSTERED ([cTermoAceitPlatfPj] ASC,[nVrsaoTermoAceit] ASC)
go

CREATE NONCLUSTERED INDEX [XIF1tTermoAceit] ON [tTermoAceit]
( 
	[cTpoTermoAceit]      ASC
)
go

CREATE TABLE [tTermoAceitUsuar]
( 
	[cUsuarPlatfPj]      integer  NOT NULL ,
	[cTermoAceitPlatfPj] smallint  NOT NULL ,
	[nVrsaoTermoAceit]   smallint  NOT NULL ,
	[dAceitTermoUsuar]   datetime  NOT NULL ,
	[dExpirAceitTermoUsuar] date  NULL 
)
go

ALTER TABLE [tTermoAceitUsuar]
	ADD CONSTRAINT [XPKtTermoAceitUsuar] PRIMARY KEY  CLUSTERED ([cUsuarPlatfPj] ASC,[cTermoAceitPlatfPj] ASC,[nVrsaoTermoAceit] ASC)
go

CREATE TABLE [tTpoCntatUsuarPj]
( 
	[cTpoCntatUsuar]     smallint  NOT NULL ,
	[rTpoCntatUsuar]     varchar(120)  NOT NULL 
)
go

ALTER TABLE [tTpoCntatUsuarPj]
	ADD CONSTRAINT [XPKtTpoCntatUsuarPj] PRIMARY KEY  CLUSTERED ([cTpoCntatUsuar] ASC)
go

CREATE TABLE [tTpoNotifUsuar]
( 
	[cTpoNotifUsuar]     smallint  NOT NULL ,
	[rTpoNotifUsuar]     varchar(120)  NOT NULL 
)
go

ALTER TABLE [tTpoNotifUsuar]
	ADD CONSTRAINT [XPKtTpoNotifUsuar] PRIMARY KEY  CLUSTERED ([cTpoNotifUsuar] ASC)
go

CREATE TABLE [tTpoTermoAceit]
( 
	[cTpoTermoAceit]     smallint  NOT NULL ,
	[rTpoTermoAceit]     varchar(80)  NOT NULL 
)
go

ALTER TABLE [tTpoTermoAceit]
	ADD CONSTRAINT [XPKtTpoTermoAceit] PRIMARY KEY  CLUSTERED ([cTpoTermoAceit] ASC)
go

CREATE TABLE [tUsuarEmprPlatfPj]
( 
	[cUsuarPlatfPj]      integer  NOT NULL ,
	[cEmprPlatfPj]       integer  NOT NULL 
)
go

ALTER TABLE [tUsuarEmprPlatfPj]
	ADD CONSTRAINT [XPKtUsuarEmprPlatfPj] PRIMARY KEY  CLUSTERED ([cUsuarPlatfPj] ASC,[cEmprPlatfPj] ASC)
go

CREATE TABLE [tUsuarPlatfPj]
( 
	[cUsuarPlatfPj]      integer  NOT NULL ,
	[iUsuarPlatfPj]      varchar(120)  NOT NULL ,
	[rApldoUsuarPlatfPj] varchar(45)  NULL ,
	[dNascUsuarPlatfPj]  date  NOT NULL ,
	[iMaeUsuarPlatfPj]   varchar(120)  NOT NULL ,
	[dCadUsuarPlatfPj]   datetime  NOT NULL ,
	[wSenhaUsuarPlatfPj] nvarchar(128)  NULL ,
	[nCpfUsuarPlatfPj]   decimal(9)  NOT NULL ,
	[nCtrlCpfUsuarPlatfPj] decimal(2)  NOT NULL ,
	[cSitUsuarPlatfPj]   decimal(1)  NOT NULL 
)
go

ALTER TABLE [tUsuarPlatfPj]
	ADD CONSTRAINT [XPKtUsuarPlatfPj] PRIMARY KEY  CLUSTERED ([cUsuarPlatfPj] ASC)
go

ALTER TABLE [tUsuarPlatfPj]
	ADD CONSTRAINT [XAK1tUsuarPlatfPj] UNIQUE ([nCpfUsuarPlatfPj]  ASC,[nCtrlCpfUsuarPlatfPj]  ASC)
go


ALTER TABLE [tAceitNotifUsuarPj]
	ADD CONSTRAINT [FKtUsuarPlatfPj03] FOREIGN KEY ([cUsuarPlatfPj]) REFERENCES [tUsuarPlatfPj]([cUsuarPlatfPj])
go

ALTER TABLE [tAceitNotifUsuarPj]
	ADD CONSTRAINT [FKtTpoNotifUsuar01] FOREIGN KEY ([cTpoNotifUsuar]) REFERENCES [tTpoNotifUsuar]([cTpoNotifUsuar])
go


ALTER TABLE [tCntatUsuarPlatfPj]
	ADD CONSTRAINT [FKtTpoCntatUsuarPj01] FOREIGN KEY ([cTpoCntatUsuar]) REFERENCES [tTpoCntatUsuarPj]([cTpoCntatUsuar])
go

ALTER TABLE [tCntatUsuarPlatfPj]
	ADD CONSTRAINT [FKtUsuarPlatfPj04] FOREIGN KEY ([cUsuarPlatfPj]) REFERENCES [tUsuarPlatfPj]([cUsuarPlatfPj])
go


ALTER TABLE [tTermoAceit]
	ADD CONSTRAINT [FKtTpoTermoAceit01] FOREIGN KEY ([cTpoTermoAceit]) REFERENCES [tTpoTermoAceit]([cTpoTermoAceit])
go


ALTER TABLE [tTermoAceitUsuar]
	ADD CONSTRAINT [FKtTermoAceit01] FOREIGN KEY ([cTermoAceitPlatfPj],[nVrsaoTermoAceit]) REFERENCES [tTermoAceit]([cTermoAceitPlatfPj],[nVrsaoTermoAceit])
go

ALTER TABLE [tTermoAceitUsuar]
	ADD CONSTRAINT [FKtUsuarPlatfPj02] FOREIGN KEY ([cUsuarPlatfPj]) REFERENCES [tUsuarPlatfPj]([cUsuarPlatfPj])
go


ALTER TABLE [tUsuarEmprPlatfPj]
	ADD CONSTRAINT [FKtUsuarPlatfPj01] FOREIGN KEY ([cUsuarPlatfPj]) REFERENCES [tUsuarPlatfPj]([cUsuarPlatfPj])
go

ALTER TABLE [tUsuarEmprPlatfPj]
	ADD CONSTRAINT [FKtEmprPlatfPj01] FOREIGN KEY ([cEmprPlatfPj]) REFERENCES [tEmprPlatfPj]([cEmprPlatfPj])
go

