IF (NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'pes')) 
BEGIN
    EXEC ('CREATE SCHEMA [pes] AUTHORIZATION [dbo]')
END
GO
