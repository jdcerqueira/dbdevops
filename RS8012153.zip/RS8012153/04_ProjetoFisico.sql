CREATE SEQUENCE [dbo].[sqCtaEmprPlatfPj] 
 AS [int]
 START WITH 1
 INCREMENT BY 1
 MINVALUE -2147483648
 MAXVALUE 2147483647
 CYCLE 
 CACHE  500 
GO
 

CREATE TABLE [tCtaEmprPlatfPj]
( 
	[cCtaEmprPlatfPj]    integer  NOT NULL ,
	[cEmprPlatfPj]       integer  NOT NULL ,
	[nContrEmprNe]       integer  NULL ,
	[nCtaCorr]           integer  NOT NULL ,
	[dCriacCtaCorrCanal] datetime  NOT NULL ,
	[dExclCtaCorrCanal]  datetime  NULL ,
	[cBcoAgCli]          decimal(3)  NOT NULL ,
	[cAgCtaCli]          decimal(5)  NOT NULL 
)
go

CREATE UNIQUE CLUSTERED INDEX [XPKtCtaEmprPlatfPj] ON [tCtaEmprPlatfPj]
( 
	[cCtaEmprPlatfPj]     ASC
)
go

CREATE NONCLUSTERED INDEX [XIF2tCtaEmprPlatfPj] ON [tCtaEmprPlatfPj]
( 
	[nContrEmprNe]        ASC
)
go

CREATE NONCLUSTERED INDEX [XIF3tCtaEmprPlatfPj] ON [tCtaEmprPlatfPj]
( 
	[cBcoAgCli]           ASC,
	[cAgCtaCli]           ASC
)
go

CREATE NONCLUSTERED INDEX [XIF4tCtaEmprPlatfPj] ON [tCtaEmprPlatfPj]
( 
	[cEmprPlatfPj]        ASC
)
go

ALTER TABLE [tCtaEmprPlatfPj]
	ADD CONSTRAINT [FKtEmprPlatfPj02] FOREIGN KEY ([cEmprPlatfPj]) REFERENCES [tEmprPlatfPj]([cEmprPlatfPj])
go

