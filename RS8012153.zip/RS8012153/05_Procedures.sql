USE [PDPJD004]
GO

/****** Object:  StoredProcedure [pes].[pDelTermoAceitUsuar01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelTermoAceitUsuar01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelTermoAceitUsuar01_v1]
GO

/****** Object:  StoredProcedure [pes].[pDelCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelCntatUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelCntatUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pDelAceitNotifUsuarPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelAceitNotifUsuarPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelAceitNotifUsuarPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pUpdCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdCntatUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdCntatUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj02]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdUsuarPlatfPj02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdUsuarPlatfPj02]
GO

/****** Object:  StoredProcedure [pes].[pUpdEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj03]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj03]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj03]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj02]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj02]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pSelTermoAceit01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelTermoAceit01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelTermoAceit01]
GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj02]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelEmprPlatfPj02]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelEmprPlatfPj02]
GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pInsNotifUsuarPlatPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsNotifUsuarPlatPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsNotifUsuarPlatPj01]
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsUsuarEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsUsuarEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pInsCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsCntatUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsCntatUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pInsEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelUsuarEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelUsuarEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pDelTermoAceitUsuar01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelTermoAceitUsuar01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelTermoAceitUsuar01]
GO

/****** Object:  StoredProcedure [pes].[pDelCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelCntatUsuarPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelCntatUsuarPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pDelAceitNotifUsuarPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelAceitNotifUsuarPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelAceitNotifUsuarPj01]
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpdCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdCntatUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdCntatUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj02_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdUsuarPlatfPj02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdUsuarPlatfPj02_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpdEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj03_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj03_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj03_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj02_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj02_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelTermoAceit01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelTermoAceit01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelTermoAceit01_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj02_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelEmprPlatfPj02_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelEmprPlatfPj02_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsNotifUsuarPlatPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsNotifUsuarPlatPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsNotifUsuarPlatPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsUsuarEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsUsuarEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsCntatUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsCntatUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelUsuarPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelUsuarPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pDelUsuarEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pDelUsuarEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pInsTermoAceitUsuar01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsTermoAceitUsuar01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsTermoAceitUsuar01]
GO

/****** Object:  StoredProcedure [pes].[pInsTermoAceitUsuar01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pInsTermoAceitUsuar01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pInsTermoAceitUsuar01_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarCntaEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarCntaEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpEmprInsCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpEmprInsCntaEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpEmprInsCntaEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pSelUsuarCntaEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pSelUsuarCntaEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pUpEmprInsCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpEmprInsCntaEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpEmprInsCntaEmprPlatfPj01]
GO

/****** Object:  StoredProcedure [pes].[pUpdEmprInsCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdEmprInsCntaEmprPlatfPj01_v1]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdEmprInsCntaEmprPlatfPj01_v1]
GO

/****** Object:  StoredProcedure [pes].[pUpdEmprInsCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:41:23 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[pes].[pUpdEmprInsCntaEmprPlatfPj01]') AND type in (N'P', N'PC'))
DROP PROCEDURE [pes].[pUpdEmprInsCntaEmprPlatfPj01]
GO



/****** Object:  StoredProcedure [pes].[pUpdEmprInsCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:40:20 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE  [pes].[pUpdEmprInsCntaEmprPlatfPj01]
(
	@dbversion				int,
	@nCpfUsuarPlatfPj		int,
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@nFlialCnpjPlatfPj      decimal(4,0),
	@nCtrlCnpjPlatfPj       decimal(2,0),
	@iRzScialPlatfPj        varchar(120),
	@nContrEmprNe           int,
	@nCtaCorr               int,
	@cBcoAgCli              decimal(3),
	@cAgCtaCli              decimal(5)
)
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpdEmprInsCntaEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj,
	                       @nCnpjEmprPlatfPj,
						   @nFlialCnpjPlatfPj,
						   @nCtrlCnpjPlatfPj,
	                       @iRzScialPlatfPj,
	                       @nContrEmprNe,
	                       @nCtaCorr,
	                       @cBcoAgCli,
	                       @cAgCtaCli
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END


GO

GRANT EXECUTE ON [pes].[pUpdEmprInsCntaEmprPlatfPj01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pes].[pUpdEmprInsCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pUpdEmprInsCntaEmprPlatfPj01_v1]
(
	@nCpfUsuarPlatfPj		int,
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@nFlialCnpjPlatfPj      decimal(4,0),
	@nCtrlCnpjPlatfPj       decimal(2,0),
	@iRzScialPlatfPj        varchar(120),
	@nContrEmprNe           int,
	@nCtaCorr               int,
	@cBcoAgCli              decimal(3),
	@cAgCtaCli              decimal(5)

 )
AS
--
BEGIN

BEGIN TRANSACTION;

BEGIN TRY

    IF NOT EXISTS (
          SELECT cEmprPlatfPj
          FROM   [dbo].[tEmprPlatfPj]
          WHERE  nCnpjEmprPlatfPj = @nCnpjEmprPlatfPj)
     BEGIN
       INSERT INTO [dbo].[tEmprPlatfPj]
	    (
	    [cEmprPlatfPj],
	    [nCnpjEmprPlatfPj],
		[nFlialCnpjPlatfPj],
		[nCtrlCnpjPlatfPj],
		[iRzScialPlatfPj],
		[dCadEmprPlatfPj]
		)
	 SELECT NEXT VALUE FOR [dbo].[sqEmprPlatfPj],
	    @nCnpjEmprPlatfPj,
		@nFlialCnpjPlatfPj,
		@nCtrlCnpjPlatfPj,
		@iRzScialPlatfPj,
		CURRENT_TIMESTAMP

     END

    DECLARE @cEmprPlatfPj int;
    SET @cEmprPlatfPj =
       (
          SELECT cEmprPlatfPj
          FROM   [dbo].[tEmprPlatfPj]
          WHERE  nCnpjEmprPlatfPj = @nCnpjEmprPlatfPj
       )
	INSERT INTO [dbo].[tCtaEmprPlatfPj]
           (
		   [cCtaEmprPlatfPj],
           [cEmprPlatfPj],
           [nContrEmprNe],
           [nCtaCorr],
           [dCriacCtaCorrCanal],
           [cBcoAgCli],
           [cAgCtaCli]
		   )

     SELECT NEXT VALUE FOR [dbo].[sqCtaEmprPlatfPj],
           @cEmprPlatfPj,
           @nContrEmprNe,
		   @nCtaCorr,
		   CURRENT_TIMESTAMP,
		   @cBcoAgCli,
           @cAgCtaCli

	 UPDATE
		[dbo].[tEmprPlatfPj]
	 SET
		[iRzScialPlatfPj] = @iRzScialPlatfPj

	  FROM
		[dbo].[tEmprPlatfPj]

	  WHERE
		[tEmprPlatfPj].[nCnpjEmprPlatfPj] = @nCnpjEmprPlatfPj

	 DECLARE @IdUsuario int;
     SET @IdUsuario =
        (
           SELECT cUsuarPlatfPj
           FROM   [dbo].[tUsuarPlatfPj]
           WHERE  nCpfUsuarPlatfPj = @nCpfUsuarPlatfPj
        )

	 DECLARE @IdEmpresa int;
     SET @IdEmpresa =
       (
          SELECT cEmprPlatfPj
          FROM   [dbo].[tEmprPlatfPj]
          WHERE  nCnpjEmprPlatfPj = @nCnpjEmprPlatfPj
       )

     IF NOT EXISTS (SELECT [cUsuarPlatfPj] FROM [dbo].[tUsuarEmprPlatfPj] WHERE [cUsuarPlatfPj] = @IdUsuario AND [cEmprPlatfPj] = @IdEmpresa)
      BEGIN
       INSERT INTO [dbo].[tUsuarEmprPlatfPj](cUsuarPlatfPj, cEmprPlatfPj) VALUES(@IdUsuario, @IdEmpresa);
     END

    IF @@TRANCOUNT > 0
       COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;
END CATCH;

END
GO

GRANT EXECUTE ON [pes].[pUpdEmprInsCntaEmprPlatfPj01_v1] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pes].[pUpEmprInsCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:40:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE   PROCEDURE  [pes].[pUpEmprInsCntaEmprPlatfPj01]
(
	@dbversion				int,
	@nCpfUsuarPlatfPj		int,
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@iRzScialPlatfPj        varchar(120),
	@nContrEmprNe           int,
	@nCtaCorr               int,
	@cBcoAgCli              decimal(3),
	@cAgCtaCli              decimal(5)
)
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpEmprInsCntaEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj,
	                       @nCnpjEmprPlatfPj,
	                       @iRzScialPlatfPj,
	                       @nContrEmprNe,
	                       @nCtaCorr,
	                       @cBcoAgCli,
	                       @cAgCtaCli
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END


GO

/****** Object:  StoredProcedure [pes].[pSelUsuarCntaEmprPlatfPj01]    Script Date: 16/02/2022 18:40:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE  [pes].[pSelUsuarCntaEmprPlatfPj01]
(
	@dbversion				int,
	@nCpfUsuarPlatfPj		int
)
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pSelUsuarCntaEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END


GO

/****** Object:  StoredProcedure [pes].[pUpEmprInsCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pUpEmprInsCntaEmprPlatfPj01_v1]
(
	@nCpfUsuarPlatfPj		int,
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@iRzScialPlatfPj        varchar(120),
	@nContrEmprNe           int,
	@nCtaCorr               int,
	@cBcoAgCli              decimal(3),
	@cAgCtaCli              decimal(5)

 )
AS
--
BEGIN 

BEGIN TRANSACTION;  
	
BEGIN TRY  

    DECLARE @cEmprPlatfPj int;
    SET @cEmprPlatfPj = 
       (
          SELECT cEmprPlatfPj 
          FROM   [dbo].[tEmprPlatfPj]
          WHERE  nCnpjEmprPlatfPj = @nCnpjEmprPlatfPj
       )	
	INSERT INTO [dbo].[tCtaEmprPlatfPj]
           (
		   [cCtaEmprPlatfPj],
           [cEmprPlatfPj],
           [nContrEmprNe],
           [nCtaCorr],
           [dCriacCtaCorrCanal],
           [cBcoAgCli],
           [cAgCtaCli]
		   )
 
     SELECT NEXT VALUE FOR [dbo].[sqCtaEmprPlatfPj],
           @cEmprPlatfPj, 
           @nContrEmprNe,
		   @nCtaCorr, 
		   CURRENT_TIMESTAMP,
		   @cBcoAgCli,
           @cAgCtaCli
		   
	 UPDATE
		[dbo].[tEmprPlatfPj]	
	 SET
		[iRzScialPlatfPj] = @iRzScialPlatfPj

	  FROM
		[dbo].[tEmprPlatfPj]
		
	  WHERE
		[tEmprPlatfPj].[nCnpjEmprPlatfPj] = @nCnpjEmprPlatfPj

	 DECLARE @IdUsuario int;
     SET @IdUsuario = 
        (
           SELECT cUsuarPlatfPj 
           FROM   [dbo].[tUsuarPlatfPj]
           WHERE  nCpfUsuarPlatfPj = @nCpfUsuarPlatfPj 
        )
		
	 DECLARE @IdEmpresa int;
     SET @IdEmpresa =
       (
          SELECT cEmprPlatfPj 
          FROM   [dbo].[tEmprPlatfPj]
          WHERE  nCnpjEmprPlatfPj = @nCnpjEmprPlatfPj
       )	

     IF NOT EXISTS (SELECT [cUsuarPlatfPj] FROM [dbo].[tUsuarEmprPlatfPj] WHERE [cUsuarPlatfPj] = @IdUsuario AND [cEmprPlatfPj] = @IdEmpresa)
      BEGIN
       INSERT INTO [dbo].[tUsuarEmprPlatfPj](cUsuarPlatfPj, cEmprPlatfPj) VALUES(@IdUsuario, @IdEmpresa);
     END

    IF @@TRANCOUNT > 0  
       COMMIT TRANSACTION; 
END TRY  
BEGIN CATCH  
    IF @@TRANCOUNT > 0  
        ROLLBACK TRANSACTION;  
END CATCH;  
		
END
GO

/****** Object:  StoredProcedure [pes].[pSelUsuarCntaEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Busca dados da empresa pelo id (cUsuarPlatfPj) do usuario
CREATE   PROCEDURE [pes].[pSelUsuarCntaEmprPlatfPj01_v1]  
(
	@nCpfUsuarPlatfPj	int
)
AS
--
BEGIN
	SELECT
		[tUsuarPlatfPj].[cUsuarPlatfPj]
		,[iUsuarPlatfPj]
		,[rApldoUsuarPlatfPj]
		,[dNascUsuarPlatfPj]
		,[iMaeUsuarPlatfPj]
		,[dCadUsuarPlatfPj]
		,[nCpfUsuarPlatfPj]
		,[nCtrlCpfUsuarPlatfPj]
		,[cSitUsuarPlatfPj]
		,[tCtaEmprPlatfPj].[cCtaEmprPlatfPj]
		,[tCtaEmprPlatfPj].[cEmprPlatfPj]
		,[iRzScialPlatfPj]
		,[nContrEmprNe]
		,[nCtaCorr]
		,[cBcoAgCli]
		,[cAgCtaCli]

	FROM 
		[dbo].[tUsuarPlatfPj]
	INNER JOIN
		[dbo].[tUsuarEmprPlatfPj]

	ON [tUsuarPlatfPj].[cUsuarPlatfPj] = [tUsuarEmprPlatfPj].[cUsuarPlatfPj] 

	INNER JOIN 
	    [dbo].[tEmprPlatfPj]

	ON [tEmprPlatfPj].[cEmprPlatfPj] = [tUsuarEmprPlatfPj].[cEmprPlatfPj] 

	INNER JOIN
	   [dbo].[tCtaEmprPlatfPj]
	 
	ON [tEmprPlatfPj].[cEmprPlatfPj] = [tCtaEmprPlatfPj].[cEmprPlatfPj] 

	WHERE
		[tUsuarPlatfPj].[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj
END
GO

/****** Object:  StoredProcedure [pes].[pInsTermoAceitUsuar01_v1]    Script Date: 16/02/2022 18:40:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pInsTermoAceitUsuar01_v1]  
(
	@dExpirAceitTermoUsuar date = null,
	@cUsuarPlatfPj int,
	@cTermoAceitPlatfPj int,
	@nVrsaoTermoAceit int,
	@dAceitTermoUsuar datetime
 )
AS
--
BEGIN
INSERT INTO [dbo].[tTermoAceitUsuar]
           ([dExpirAceitTermoUsuar]
           ,[cUsuarPlatfPj]
           ,[cTermoAceitPlatfPj]
           ,[nVrsaoTermoAceit]
           ,[dAceitTermoUsuar])
     VALUES
           (@dExpirAceitTermoUsuar,
            @cUsuarPlatfPj,
            @cTermoAceitPlatfPj,
            @nVrsaoTermoAceit,
            @dAceitTermoUsuar)
END



GO

/****** Object:  StoredProcedure [pes].[pInsTermoAceitUsuar01]    Script Date: 16/02/2022 18:40:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pInsTermoAceitUsuar01]  
(
    @dbversion	int,
	@dExpirAceitTermoUsuar date = null,
	@cUsuarPlatfPj int,
	@cTpoTermoAceit int,
	@nVrsaoTermoAceit int,
	@returnID int = 0 OUTPUT  
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pInsTermoAceitUsuar01',
@vSchema			nvarchar(3) = 'pes',
@pID int = 0,
@dAceitTermoUsuar datetime = GETDATE();
BEGIN
if @dbversion >= 1
	begin
		--
		set @pID = @cUsuarPlatfPj
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @dExpirAceitTermoUsuar,@cUsuarPlatfPj,@cTpoTermoAceit,@nVrsaoTermoAceit,@dAceitTermoUsuar;
		--
		set @returnID = @pID
	end
	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END



GO

GRANT EXECUTE ON [pes].[pInsTermoAceitUsuar01] TO [APLICATIVOS] AS [dbo]
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE     PROCEDURE [pes].[pDelUsuarEmprPlatfPj01_v1]
(
  @cUsuarPlatfPj  int
)
AS
--
BEGIN
 DELETE FROM [dbo].[tUsuarEmprPlatfPj]
      WHERE cUsuarPlatfPj  =  @cUsuarPlatfPj;
END
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pDelUsuarPlatfPj01_v1]
(
  @cUsuarPlatfPj int
)
AS
--
BEGIN
 DELETE FROM [dbo].[tUsuarPlatfPj]
      WHERE cUsuarPlatfPj  =  @cUsuarPlatfPj;
END
GO

/****** Object:  StoredProcedure [pes].[pInsEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pInsEmprPlatfPj01_v1]
(
  @iRzScialPlatfPj    varchar(120),
  @iFantsEmprPlatfPj   varchar(120),
  @dCadEmprPlatfPj    dateTime,
  @nCnpjEmprPlatfPj   decimal(9,0),
  @nFlialCnpjPlatfPj  decimal(4,0),
  @nCtrlCnpjPlatfPj   decimal(2,0),
  @cEmprPlatfPj       int
)
AS
--
BEGIN
  INSERT INTO [dbo].[tEmprPlatfPj]
           ([iRzScialPlatfPj]
           ,[iFantsEmprPlatfPj]
           ,[dCadEmprPlatfPj]
           ,[nCnpjEmprPlatfPj]
           ,[nFlialCnpjPlatfPj]
           ,[nCtrlCnpjPlatfPj]
           ,[cEmprPlatfPj])
     VALUES
           (@iRzScialPlatfPj,
		        @iFantsEmprPlatfPj,
		        @dCadEmprPlatfPj,
			      @nCnpjEmprPlatfPj,
		        @nFlialCnpjPlatfPj,
			      @nCtrlCnpjPlatfPj,
			      @cEmprPlatfPj
         )
END
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
CREATE   PROCEDURE [pes].[pInsUsuarPlatfPj01_v1]  
(
	@cUsuarPlatfPj int,
	@iUsuarPlatfPj varchar(120),
	@rApldoUsuarPlatfPj varchar(45),
	@dNascUsuarPlatfPj date,
	@iMaeUsuarPlatfPj varchar(120),
	@dCadUsuarPlatfPj datetime = NULL,
	@wSenhaUsuarPlatfPj nvarchar(128),
	@nCpfUsuarPlatfPj decimal(9, 0),
	@nCtrlCpfUsuarPlatfPj decimal(2, 0),
        @cSitUsuarPlatfPj int
         
 )
AS
--
BEGIN
	INSERT INTO [dbo].[tUsuarPlatfPj]
           ([cUsuarPlatfPj]
           ,[iUsuarPlatfPj]
           ,[rApldoUsuarPlatfPj]
           ,[dNascUsuarPlatfPj]
           ,[iMaeUsuarPlatfPj]
           ,[dCadUsuarPlatfPj]
           ,[wSenhaUsuarPlatfPj]
           ,[nCpfUsuarPlatfPj]
           ,[nCtrlCpfUsuarPlatfPj]
           ,[cSitUsuarPlatfPj])
     VALUES (@cUsuarPlatfPj, 
           @iUsuarPlatfPj, 
           @rApldoUsuarPlatfPj, 
           @dNascUsuarPlatfPj,
           @iMaeUsuarPlatfPj, 
           @dCadUsuarPlatfPj,
           @wSenhaUsuarPlatfPj, 
           @nCpfUsuarPlatfPj, 
           @nCtrlCpfUsuarPlatfPj,
           @cSitUsuarPlatfPj)		
END

GO

/****** Object:  StoredProcedure [pes].[pInsCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pInsCntatUsuarPlatfPj01_v1]  
(
  @cTpoCntatUsuar int,
  @cUsuarPlatfPj  int,
  @rCntatUsuarPlatfPj varchar(128) 
)
AS
--
BEGIN
   INSERT INTO [dbo].[tCntatUsuarPlatfPj]
           ([cTpoCntatUsuar]
           ,[cUsuarPlatfPj]
           ,[rCntatUsuarPlatfPj])
     VALUES (@cTpoCntatUsuar,
  	         @cUsuarPlatfPj,
             @rCntatUsuarPlatfPj)
END

GO

/****** Object:  StoredProcedure [pes].[pInsUsuarEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Insere o relacionamento entre o usuario e a empresa
CREATE   PROCEDURE [pes].[pInsUsuarEmprPlatfPj01_v1]
(
  @cUsuarPlatfPj  int,
  @cEmprPlatfPj   int
)
AS
--
BEGIN
  INSERT INTO [dbo].[tUsuarEmprPlatfPj]
           ([cUsuarPlatfPj]
           ,[cEmprPlatfPj]
           )
     VALUES
           (@cUsuarPlatfPj,
		        @cEmprPlatfPj
         )
END
GO

/****** Object:  StoredProcedure [pes].[pInsNotifUsuarPlatPj01_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pInsNotifUsuarPlatPj01_v1]
(
  @cTpoNotifUsuar int,
  @cUsuarPlatfPj  int,
  @dAceitNotifUsuar datetime = NULL
)
AS
--
BEGIN
   INSERT INTO [dbo].[tAceitNotifUsuarPj]
           ([cUsuarPlatfPj]
           ,[cTpoNotifUsuar]
           ,[dAceitNotifUsuar])
     VALUES (@cUsuarPlatfPj,
  	         @cTpoNotifUsuar,
             @dAceitNotifUsuar)
END

GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Busca dados da empresa pelo cpf do usuario
CREATE   PROCEDURE [pes].[pSelEmprPlatfPj01_v1]  
(
	@nCpfUsuarPlatfPj		int,
	@nCtrlCpfUsuarPlatfPj	int
 )
AS
--
BEGIN
	SELECT
		[tEmprPlatfPj].[cEmprPlatfPj]
		,[iRzScialPlatfPj]
		,[iFantsEmprPlatfPj]
		,[dCadEmprPlatfPj]
		,[nCnpjEmprPlatfPj]
		,[nFlialCnpjPlatfPj]
		,[nCtrlCnpjPlatfPj]
	FROM 
		[dbo].[tEmprPlatfPj]
	INNER JOIN
		[dbo].[tUsuarEmprPlatfPj]
	ON [tEmprPlatfPj].[cEmprPlatfPj] = [tUsuarEmprPlatfPj].[cEmprPlatfPj] 
	INNER JOIN
		[dbo].[tUsuarPlatfPj]
	ON [tUsuarEmprPlatfPj].[cUsuarPlatfPj] = [tUsuarPlatfPj].[cUsuarPlatfPj] 
	WHERE
		[tUsuarPlatfPj].[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj 
	 AND
		[tUsuarPlatfPj].[nCtrlCpfUsuarPlatfPj] = @nCtrlCpfUsuarPlatfPj
END

GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj02_v1]    Script Date: 16/02/2022 18:40:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Busca dados da empresa pelo id (cUsuarPlatfPj) do usuario
CREATE   PROCEDURE [pes].[pSelEmprPlatfPj02_v1]  
(
	@cUsuarPlatfPj	int
 )
AS
--
BEGIN
	SELECT
		[tEmprPlatfPj].[cEmprPlatfPj]
		,[iRzScialPlatfPj]
		,[iFantsEmprPlatfPj]
		,[dCadEmprPlatfPj]
		,[nCnpjEmprPlatfPj]
		,[nFlialCnpjPlatfPj]
		,[nCtrlCnpjPlatfPj]
	FROM 
		[dbo].[tEmprPlatfPj]
	INNER JOIN
		[dbo].[tUsuarEmprPlatfPj]
	ON [tEmprPlatfPj].[cEmprPlatfPj] = [tUsuarEmprPlatfPj].[cEmprPlatfPj] 
	WHERE
		[cUsuarPlatfPj] = @cUsuarPlatfPj
END

GO

/****** Object:  StoredProcedure [pes].[pSelTermoAceit01_v1]    Script Date: 16/02/2022 18:40:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pSelTermoAceit01_v1]  

AS
--
BEGIN
    SELECT [cTpoTermoAceit],
           [rTermoAceitPlatfPj],
           [dFimVgciaTermoAceit],
	   [dInicVgciaTermoAceit],
	   [nVrsaoTermoAceit]
  FROM 
     [dbo].[tTermoAceit]
  WHERE ([dInicVgciaTermoAceit] <= GETDATE() AND
        ([dFimVgciaTermoAceit] is null OR [dFimVgciaTermoAceit] >= GETDATE()))
  
END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
/*
CREATE OR ALTER PROCEDURE [pes].[pSelUsuarPlatfPj01_v1]  
(
	@pMaxRows int = 100
 )
AS
--
BEGIN
	SELECT TOP (@pMaxRows)
           [cUsuarPlatfPj]
           ,[iUsuarPlatfPj]
           ,[rApldoUsuarPlatfPj]
           ,[dNascUsuarPlatfPj]
           ,[iMaeUsuarPlatfPj]
           ,[dCadUsuarPlatfPj]
           ,[wSenhaUsuarPlatfPj]
           ,[nCpfUsuarPlatfPj]
           ,[nCtrlCpfUsuarPlatfPj]
     FROM 
		[dbo].[tUsuarPlatfPj]	
END
GO
*/


-- Create the stored procedure in the specified schema
CREATE   PROCEDURE [pes].[pSelUsuarPlatfPj01_v1]  
(
	@pMaxRows int = 100
 )
AS
--
BEGIN
	SELECT TOP (@pMaxRows)
           [cUsuarPlatfPj]
           ,[iUsuarPlatfPj]
           ,[rApldoUsuarPlatfPj]
           ,[dNascUsuarPlatfPj]
           ,[iMaeUsuarPlatfPj]
           ,[dCadUsuarPlatfPj]
           ,[wSenhaUsuarPlatfPj]
           ,[nCpfUsuarPlatfPj]
           ,[nCtrlCpfUsuarPlatfPj]
     FROM 
		[dbo].[tUsuarPlatfPj]	
END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj02_v1]    Script Date: 16/02/2022 18:40:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
CREATE    PROCEDURE [pes].[pSelUsuarPlatfPj02_v1]  
(
	@nCpfUsuarPlatfPj int,
	@nCtrlCpfUsuarPlatfPj int
 )
AS
--
DECLARE
@emailType int = 1,
@phoneType int = 2
BEGIN
	SELECT
            [CUSTOMER].[cUsuarPlatfPj]
            ,[iUsuarPlatfPj]
            ,[rApldoUsuarPlatfPj]
            ,[dNascUsuarPlatfPj]
            ,[iMaeUsuarPlatfPj]
            ,[dCadUsuarPlatfPj]
            ,[wSenhaUsuarPlatfPj]
            ,[nCpfUsuarPlatfPj]
            ,[nCtrlCpfUsuarPlatfPj]
            ,[cSitUsuarPlatfPj]
            ,[CONT_EMAIL].rCntatUsuarPlatfPj AS email
            ,[CONT_PHONE].rCntatUsuarPlatfPj AS phone
      FROM 
		[dbo].[tUsuarPlatfPj] [CUSTOMER]
      INNER JOIN 
            [dbo].[tCntatUsuarPlatfPj] [CONT_EMAIL]
            ON [CONT_EMAIL].[cUsuarPlatfPj] = [CUSTOMER].[cUsuarPlatfPj]
            AND [CONT_EMAIL].[cTpoCntatUsuar] = @emailType
      INNER JOIN 
		[dbo].[tCntatUsuarPlatfPj] [CONT_PHONE]
            ON [CONT_PHONE].[cUsuarPlatfPj] = [CUSTOMER].[cUsuarPlatfPj]
            AND [CONT_PHONE].[cTpoCntatUsuar] = @phoneType
      WHERE
		[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj
	AND
		[nCtrlCpfUsuarPlatfPj] = @nCtrlCpfUsuarPlatfPj
END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj03_v1]    Script Date: 16/02/2022 18:40:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pSelUsuarPlatfPj03_v1]
(
	@wSenhaUsuarPlatfPj nvarchar(128),
	@nCpfUsuarPlatfPj int,
	@nCtrlCpfUsuarPlatfPj int
 )
AS
--
BEGIN
	SELECT
           [cSitUsuarPlatfPj],
		   [cUsuarPlatfPj]
     FROM 
		[dbo].[tUsuarPlatfPj]
     WHERE
		[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj 
	 AND
		[nCtrlCpfUsuarPlatfPj] = @nCtrlCpfUsuarPlatfPj 
	 AND
		[wSenhaUsuarPlatfPj] = @wSenhaUsuarPlatfPj 
END

GO

/****** Object:  StoredProcedure [pes].[pUpdEmprPlatfPj01_v1]    Script Date: 16/02/2022 18:40:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pUpdEmprPlatfPj01_v1]
(
	@cEmprPlatfPj 			int,
	@nCpfUsuarPlatfPj		int,
	@nCtrlCpfUsuarPlatfPj	int,
	@iFantsEmprPlatfPj   	varchar(120),
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@nFlialCnpjPlatfPj  	decimal(4,0),
	@nCtrlCnpjPlatfPj   	decimal(2,0)
 )
AS
--
BEGIN

	UPDATE
		[dbo].[tEmprPlatfPj]	
	SET
		[iFantsEmprPlatfPj] = @iFantsEmprPlatfPj,
		[nCnpjEmprPlatfPj] = @nCnpjEmprPlatfPj,
		[nFlialCnpjPlatfPj] = @nFlialCnpjPlatfPj,
		[nCtrlCnpjPlatfPj] = @nCtrlCnpjPlatfPj
	FROM 
		[dbo].[tEmprPlatfPj]
	INNER JOIN
		[dbo].[tUsuarEmprPlatfPj]
	ON
		[tEmprPlatfPj].[cEmprPlatfPj] = [tUsuarEmprPlatfPj].[cEmprPlatfPj]
	INNER JOIN
		[dbo].[tUsuarPlatfPj]
	ON
		[tUsuarEmprPlatfPj].[cUsuarPlatfPj] = [tUsuarPlatfPj].[cUsuarPlatfPj] 
	WHERE
		[tEmprPlatfPj].[cEmprPlatfPj] = @cEmprPlatfPj
	AND
		[tUsuarPlatfPj].[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj
	AND
		[tUsuarPlatfPj].[nCtrlCpfUsuarPlatfPj] = @nCtrlCpfUsuarPlatfPj
END
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj02_v1]    Script Date: 16/02/2022 18:40:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdUsuarPlatfPj02_v1]
(
	@cUsuarPlatfPj			int,
	@iUsuarPlatfPj			varchar(120),
	@rApldoUsuarPlatfPj		varchar(45),
	@dNascUsuarPlatfPj		date,
	@iMaeUsuarPlatfPj		varchar(120)
 )
AS
--
BEGIN
	UPDATE [dbo].[tUsuarPlatfPj]
	SET
		[iUsuarPlatfPj] = @iUsuarPlatfPj,
		[rApldoUsuarPlatfPj] = @rApldoUsuarPlatfPj,
		[dNascUsuarPlatfPj] = @dNascUsuarPlatfPj,
		[iMaeUsuarPlatfPj] = @iMaeUsuarPlatfPj
    WHERE
		[cUsuarPlatfPj] = @cUsuarPlatfPj
END
GO

/****** Object:  StoredProcedure [pes].[pUpdCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdCntatUsuarPlatfPj01_v1]
(
	@cUsuarPlatfPj			int,
	@cTpoCntatUsuar			int,
	@rCntatUsuarPlatfPj		varchar(128) 
 )
AS
--
BEGIN
	UPDATE [dbo].[tCntatUsuarPlatfPj]
	SET
		[rCntatUsuarPlatfPj] = @rCntatUsuarPlatfPj
    WHERE
		[cUsuarPlatfPj] = @cUsuarPlatfPj
	AND
		[cTpoCntatUsuar] = @cTpoCntatUsuar
END
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdUsuarPlatfPj01_v1]
(
	@nCpfUsuarPlatfPj     int,
	@nCtrlCpfUsuarPlatfPj int,
	@cSitUsuarPlatfPj int
 )
AS
--
BEGIN
	UPDATE [dbo].[tUsuarPlatfPj]
	SET [cSitUsuarPlatfPj] = @cSitUsuarPlatfPj
     WHERE
		[nCpfUsuarPlatfPj] = @nCpfUsuarPlatfPj
	AND
	   [nCtrlCpfUsuarPlatfPj] = @nCtrlCpfUsuarPlatfPj
END
GO

/****** Object:  StoredProcedure [pes].[pDelAceitNotifUsuarPj01]    Script Date: 16/02/2022 18:40:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE      PROCEDURE [pes].[pDelAceitNotifUsuarPj01]
(
	@dbversion		     int,
	@cUsuarPlatfPj     int

 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pDelAceitNotifUsuarPj01',
@vSchema			    nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' + CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

end
GO

/****** Object:  StoredProcedure [pes].[pDelCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pDelCntatUsuarPlatfPj01]
(
	@dbversion		   int,
  @cUsuarPlatfPj   int

 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pDelCntatUsuarPlatfPj01',
@vSchema			    nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer  @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

end
GO

/****** Object:  StoredProcedure [pes].[pDelTermoAceitUsuar01]    Script Date: 16/02/2022 18:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE      PROCEDURE [pes].[pDelTermoAceitUsuar01]
(
	  @dbversion		    int,
    @cUsuarPlatfPj    int

 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pDelTermoAceitUsuar01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer  @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

end

GO

/****** Object:  StoredProcedure [pes].[pDelUsuarEmprPlatfPj01]    Script Date: 16/02/2022 18:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pDelUsuarEmprPlatfPj01]
(
	@dbversion		   int,
  @cUsuarPlatfPj   int

 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pDelUsuarEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer  @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

end
GO

/****** Object:  StoredProcedure [pes].[pDelUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pDelUsuarPlatfPj01]
(
	@dbversion		   int,
  @cUsuarPlatfPj   int

 )
AS
--
DECLARE
@vProcNameVer  nvarchar(100) = 'pDelUsuarPlatfPj01',
@vSchema			 nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer  @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

end
GO

/****** Object:  StoredProcedure [pes].[pInsEmprPlatfPj01]    Script Date: 16/02/2022 18:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pInsEmprPlatfPj01]
(
	@dbversion		      int,
	@iRzScialPlatfPj      varchar(120),
	@iFantsEmprPlatfPj     varchar(120),
    @dCadEmprPlatfPj      dateTime,
    @nCnpjEmprPlatfPj     decimal(9,0),
    @nFlialCnpjPlatfPj    decimal(4,0),
    @nCtrlCnpjPlatfPj     decimal(2,0),
	@returnID             int = 0 OUTPUT
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pInsEmprPlatfPj01',
@pID                int = 0,
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @pID = (NEXT VALUE FOR [dbo].[sqEmprPlatfPj])
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer @iRzScialPlatfPj, @iFantsEmprPlatfPj, @dCadEmprPlatfPj, @nCnpjEmprPlatfPj, @nFlialCnpjPlatfPj, @nCtrlCnpjPlatfPj, @pID;
		--
		set @returnID = @pID
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

END
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:26 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
CREATE   PROCEDURE [pes].[pInsUsuarPlatfPj01]  
(
	@dbversion		int,
	@iUsuarPlatfPj varchar(120),
	@rApldoUsuarPlatfPj varchar(45),
	@dNascUsuarPlatfPj date,
	@iMaeUsuarPlatfPj varchar(120),
	@dCadUsuarPlatfPj datetime = NULL,
	@wSenhaUsuarPlatfPj nvarchar(128),
	@nCpfUsuarPlatfPj decimal(9, 0),
	@nCtrlCpfUsuarPlatfPj decimal(2, 0) ,
	@returnID int = 0 OUTPUT  
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pInsUsuarPlatfPj01',
@vSchema			nvarchar(3) = 'pes',
@pID int = 0,
@cSitUsuarPlatfPj int = 0;
BEGIN
	-- set procedure router name
	--set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' + convert(varchar, @dbversion));
	-- set default parameters
	IF @dCadUsuarPlatfPj is null
	SET @dCadUsuarPlatfPj = getdate()
	--
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		--
		set @pID = (NEXT VALUE FOR [dbo].[sqEmprPlatfPj])
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @pID, @iUsuarPlatfPj, @rApldoUsuarPlatfPj, @dNascUsuarPlatfPj, @iMaeUsuarPlatfPj, 
			@dCadUsuarPlatfPj,@wSenhaUsuarPlatfPj, @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj, @cSitUsuarPlatfPj;
		--
		set @returnID = @pID
	end
	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
	--
END

GO

/****** Object:  StoredProcedure [pes].[pInsCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pInsCntatUsuarPlatfPj01]  
(
  @dbversion		int,
  @cUsuarPlatfPj  int,
  @email varchar(128),
  @phone  varchar(128),
  @returnID int = 0 OUTPUT 
)
AS
--
DECLARE 
@vProcNameVer nvarchar(100) = 'pInsCntatUsuarPlatfPj01',
@vSchema	  nvarchar(3) = 'pes',
@emailType int = 1,
@phoneType int = 2
BEGIN
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		--
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @emailType, @cUsuarPlatfPj, @email;
		exec @vProcNameVer @phoneType, @cUsuarPlatfPj, @phone;
		--
		set @returnID = @cUsuarPlatfPj;
	end
	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
	--
END
GO

/****** Object:  StoredProcedure [pes].[pInsUsuarEmprPlatfPj01]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Insere o relacionamento entre o usuario e a empresa
CREATE   PROCEDURE [pes].[pInsUsuarEmprPlatfPj01]
(
	@dbversion		int,
	@cUsuarPlatfPj	int,
	@cEmprPlatfPj	int
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pInsUsuarEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));

		exec @vProcNameVer @cUsuarPlatfPj, @cEmprPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

END
GO

/****** Object:  StoredProcedure [pes].[pInsNotifUsuarPlatPj01]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- Create the stored procedure in the specified schema
CREATE   PROCEDURE [pes].[pInsNotifUsuarPlatPj01]
(
	@dbversion		int,
	@cTpoNotifUsuar int,
  @cUsuarPlatfPj  int,
  @dAceitNotifUsuar datetime = NULL
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pInsNotifUsuarPlatPj01',
@vSchema			nvarchar(3) = 'pes',
@pID int = 0,
@cSitUsuarPlatfPj int = 0;
BEGIN
	-- set procedure router name
	--set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' + convert(varchar, @dbversion));
	-- set default parameters
	IF @dAceitNotifUsuar is null
	SET @dAceitNotifUsuar = getdate()
	--
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		--
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @cTpoNotifUsuar, @cUsuarPlatfPj, @dAceitNotifUsuar;
		--
	end
	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end
	--
END

GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj01]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Busca dados da empresa pelo cpf do usuario
CREATE   PROCEDURE [pes].[pSelEmprPlatfPj01]
(
	@dbversion				int,
	@nCpfUsuarPlatfPj		int,
	@nCtrlCpfUsuarPlatfPj	int
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

END

GO

/****** Object:  StoredProcedure [pes].[pSelEmprPlatfPj02]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Busca dados da empresa pelo id (cUsuarPlatfPj) do usuario
CREATE   PROCEDURE [pes].[pSelEmprPlatfPj02]
(
	@dbversion			int,
	@cUsuarPlatfPj		int
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelEmprPlatfPj02',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @cUsuarPlatfPj;
		--
	end

	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState);
		--
	end

END

GO

/****** Object:  StoredProcedure [pes].[pSelTermoAceit01]    Script Date: 16/02/2022 18:40:27 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE       PROCEDURE [pes].[pSelTermoAceit01]  
(
	@dbversion			int
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelTermoAceit01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN

	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer;
		--
	end

END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
CREATE   PROCEDURE [pes].[pSelUsuarPlatfPj01]  
(
	@dbversion		int,
	@pMaxRows int = 100
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelUsuarPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	-- set procedure router name
	--set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' + convert(varchar, @dbversion));
	--
	-- set default parameters
	IF @pMaxRows > 100
	SET @pMaxRows = 100
	--
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		--
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @pMaxRows;
		--
	end
	--
	-- If this version does not exist, throw an error
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
	--
END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj02]    Script Date: 16/02/2022 18:40:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-- Create the stored procedure in the specified schema
CREATE    PROCEDURE [pes].[pSelUsuarPlatfPj02]  
(
	@dbversion		      int,
	@nCpfUsuarPlatfPj     int,
	@nCtrlCpfUsuarPlatfPj int
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelUsuarPlatfPj02',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	-- set procedure router name
	--set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' + convert(varchar, @dbversion));
	--
	-- set default parameters
	-- no default parameters
	--
	-- Check if the versioned procedure exists, run it.
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj;
		--
	end

END

GO

/****** Object:  StoredProcedure [pes].[pSelUsuarPlatfPj03]    Script Date: 16/02/2022 18:40:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pSelUsuarPlatfPj03]  
(
	@dbversion		      int,
	@wSenhaUsuarPlatfPj nvarchar(128),
	@nCpfUsuarPlatfPj int,
	@nCtrlCpfUsuarPlatfPj int
 )
AS
--
DECLARE 
@vProcNameVer 		nvarchar(100) = 'pSelUsuarPlatfPj03',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @wSenhaUsuarPlatfPj, @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj;
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end

END

GO

/****** Object:  StoredProcedure [pes].[pUpdEmprPlatfPj01]    Script Date: 16/02/2022 18:40:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pUpdEmprPlatfPj01]
(
	@dbversion				int,
	@cEmprPlatfPj 			int,
	@nCpfUsuarPlatfPj		int,
	@nCtrlCpfUsuarPlatfPj	int,
	@iFantsEmprPlatfPj   	varchar(120),
	@nCnpjEmprPlatfPj   	decimal(9,0),
	@nFlialCnpjPlatfPj  	decimal(4,0),
	@nCtrlCnpjPlatfPj   	decimal(2,0)
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpdEmprPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @cEmprPlatfPj, @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj, @iFantsEmprPlatfPj, @nCnpjEmprPlatfPj, @nFlialCnpjPlatfPj, @nCtrlCnpjPlatfPj;
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj02]    Script Date: 16/02/2022 18:40:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdUsuarPlatfPj02]
(
	@dbversion				int,
	@cUsuarPlatfPj			int,
	@iUsuarPlatfPj			varchar(120),
	@rApldoUsuarPlatfPj		varchar(45),
	@dNascUsuarPlatfPj		date,
	@iMaeUsuarPlatfPj		varchar(120)
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpdUsuarPlatfPj02',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @cUsuarPlatfPj, @iUsuarPlatfPj, @rApldoUsuarPlatfPj, @dNascUsuarPlatfPj, @iMaeUsuarPlatfPj;
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END
GO

/****** Object:  StoredProcedure [pes].[pUpdCntatUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdCntatUsuarPlatfPj01]
(
	@dbversion				int,
	@cUsuarPlatfPj			int,
	@email					varchar(128),
	@phone					varchar(128)
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpdCntatUsuarPlatfPj01',
@vSchema			nvarchar(3) = 'pes',
@emailType int = 1,
@phoneType int = 2;
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @cUsuarPlatfPj, @emailType, @email;
		exec @vProcNameVer @cUsuarPlatfPj, @phoneType, @phone;
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END
GO

/****** Object:  StoredProcedure [pes].[pUpdUsuarPlatfPj01]    Script Date: 16/02/2022 18:40:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE    PROCEDURE [pes].[pUpdUsuarPlatfPj01]
(
  @dbversion		  int,
	@nCpfUsuarPlatfPj     int,
	@nCtrlCpfUsuarPlatfPj int,
	@cSitUsuarPlatfPj int
 )
AS
--
DECLARE
@vProcNameVer 		nvarchar(100) = 'pUpdUsuarPlatfPj01',
@vSchema			nvarchar(3) = 'pes';
--
BEGIN
	if @dbversion >= 1
	begin
		-- set procedure name
		set @vProcNameVer = (select @vSchema + '.' + @vProcNameVer + '_v' +  CAST( @dbversion AS NVARCHAR));
		exec @vProcNameVer @nCpfUsuarPlatfPj, @nCtrlCpfUsuarPlatfPj, @cSitUsuarPlatfPj;
		--
	end
	else
	begin
		--
		DECLARE @ErrorMessage NVARCHAR(255);  
		DECLARE @ErrorSeverity INT;  
		DECLARE @ErrorState INT; 

		set @ErrorMessage = 'This version of Procedure does not exists'
		set @ErrorSeverity = 10
		set @ErrorState = 1
		RAISERROR (@ErrorMessage,@ErrorSeverity,@ErrorState); 
		--
	end
END
GO

/****** Object:  StoredProcedure [pes].[pDelAceitNotifUsuarPj01_v1]    Script Date: 16/02/2022 18:40:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pDelAceitNotifUsuarPj01_v1]
   (
     @cUsuarPlatfPj   int
   )
   AS
   --
   BEGIN
    DELETE FROM [dbo].[tAceitNotifUsuarPj]
         WHERE cUsuarPlatfPj  =  @cUsuarPlatfPj;
   END
GO

/****** Object:  StoredProcedure [pes].[pDelCntatUsuarPlatfPj01_v1]    Script Date: 16/02/2022 18:40:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [pes].[pDelCntatUsuarPlatfPj01_v1]
(
  @cUsuarPlatfPj  int
)
AS
--
BEGIN
 DELETE FROM [dbo].[tCntatUsuarPlatfPj]
      WHERE cUsuarPlatfPj  =   @cUsuarPlatfPj;
END
GO

/****** Object:  StoredProcedure [pes].[pDelTermoAceitUsuar01_v1]    Script Date: 16/02/2022 18:40:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE     PROCEDURE [pes].[pDelTermoAceitUsuar01_v1]
   (
     @cUsuarPlatfPj    int
   )
   AS
   --
   BEGIN
    DELETE FROM [dbo].[tTermoAceitUsuar]
         WHERE cUsuarPlatfPj    =  @cUsuarPlatfPj;
   END
GO


